运行命令：
python3 MetaZeta.py