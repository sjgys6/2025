from typing import Dict, List, Optional
import time
import logging
import json
from datetime import datetime
from .roles import Seller, Buyer, Advisor, Moderator
from .ai_player import create_negotiator_agent, BaseAIAgent
#from utils.logger import NegotiationLogger, setup_negotiation_logger

class NegotiationController:
    def __init__(self, config: Dict):
        """初始化谈判控制器"""
        self.config = config
        self.roles = {}  # 参与者ID -> Role对象
        self.ai_agents = {}  # 参与者ID -> AIAgent对象
        self.current_round = 1
        self.delay = config.get("delay", 0.5)
        
        # 初始化谈判状态
        self.negotiation_state = {
            "current_round": self.current_round,
            "phase": "init",
            "Seller": self.roles.get("Seller", None),  # 卖家角色
            "Buyer": self.roles.get("Buyer", None),  # 买家角色
            "product": "古董",
            "Advisor": self.roles.get("Advisor", None),  # 顾问角色
            "roles": {},
            "history": [],
            "offers": [],
            "agreement_reached": False,
            "agreement_details": None,
            "start_time": datetime.now().isoformat(),
            "impasse": False ,
            "max_rounds": 20, 
            "total_time": 1800
        }
        
        # 初始化谈判日志器
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
        self.start_time = time.time()
        self.max_duration = config.get("max_duration", 1800)  # 默认30分钟

    def update_time_remaining(self):
        """更新时间剩余状态"""
        elapsed = time.time() - self.start_time
        self.negotiation_state["time_remaining"] = max(0, self.max_duration - elapsed)

    def _log_offer(self, proposer_id: str, offer: Dict, phase: str = "proposal", is_initial: bool = False):
        """记录提案质量"""
        if hasattr(self.logger, 'log_offer'):
            self.logger.log_offer(
                proposer_id, 
                offer, 
                phase, 
                is_initial
            )

    def _log_counteroffer(self, responder_id: str, offer: Dict, acceptance: bool):
        """记录还价情况"""
        if hasattr(self.logger, 'log_counteroffer'):
            self.logger.log_counteroffer(
                responder_id, 
                offer, 
                "counteroffer",  # phase
            )
        # 如果需要记录接受状态，可以单独记录
        if acceptance:
            self.log_agreement(offer, [responder_id])

    def log_agreement(self, agreement: Dict, roles: List[str]):
        """记录协议达成"""
        if hasattr(self.logger, 'log_agreement'):
            self.logger.log_agreement(
                agreement, 
                roles
            )

    def _log_impasse(self, reason: str):
        """记录谈判僵局"""
        if hasattr(self.logger, 'log_impasse'):
            self.logger.log_impasse(
                self.current_round,
                reason
            )

    def _log_advice(self, advisor_id: str, advice: Dict, recipient_id: str):
        """记录顾问建议"""
        if hasattr(self.logger, 'log_advice'):
            self.logger.log_advice(
                advisor_id, 
                advice, 
                recipient_id
            )

    def _log_intervention(self, moderator_id: str, intervention: Dict, impasse: bool):
        """记录主持人干预"""
        if hasattr(self.logger, 'log_intervention'):
            self.logger.log_intervention(
                moderator_id, 
                intervention, 
                impasse
            )

    def initialize_negotiation(self) -> None:
        """初始化谈判，创建角色和AI代理"""
        for role_type, roles in self.config["game_settings"]["roles"].items():
            for participant_id, info in roles.items():
                # print(info)
                # 创建角色实例
                if role_type == "Seller":
                    role = Seller(participant_id, info["name"], 
                                 min_price=info["min_price"],
                                 target_price=info["target_price"],
                                 delivery_days=info["delivery_days"])
                elif role_type == "Buyer":
                    role = Buyer(participant_id, info["name"],
                                max_price=info["max_price"],
                                target_price=info["target_price"],
                                required_delivery=info["required_delivery"])
                elif role_type == "Advisor":
                    role = Advisor(participant_id, info["name"],
                                  client_type=info["client_type"],
                                  expertise=info["expertise"])
                elif role_type == "Moderator":
                    role = Moderator(participant_id, info["name"],
                                    rules=info["rules"],
                                    client_type=info["client_type"],
                                    compromising_party=info["compromising_party"])
                else:
                    raise ValueError(f"未知角色类型: {role_type}")
                
                self.roles[participant_id] = role
                self.negotiation_state["roles"][participant_id] = {
                    "name": info["name"],
                    "role": role_type,
                    "ai_model": info.get("ai_type", "unknown")
                }
                
                # 创建AI代理
                ai_type = info.get("ai_type", "default")
                logging.info(f"为 {role.name} 创建 AI 代理: {ai_type}")
                ai_config = self.config["ai_players"][ai_type]
                self.ai_agents[participant_id] = create_negotiator_agent(ai_config, role)

    def run_negotiation(self) -> None:
        """运行谈判主流程"""
        self.initialize_negotiation()
        
        # 设置谈判参数
        negotiation_topic = self.config["game_settings"]["topic"]
        max_rounds = self.config["game_settings"].get("max_rounds", 5)
        time_limit = self.config["game_settings"].get("time_limit", 30)
        
        self.negotiation_state.update({
            "topic": negotiation_topic,
            "max_rounds": max_rounds,
            "time_limit": time_limit,
            "time_remaining": time_limit * 60,
            "start_time": datetime.now().isoformat()
        })
        
        # 主持人开场
        self.start_phase()
        
        # 主谈判循环
        start_time = time.time()
        while not self.check_negotiation_end():
            elapsed_time = time.time() - start_time
            self.negotiation_state["time_remaining"] = max(0, time_limit * 60 - elapsed_time)
            self.negotiation_state["current_round"] = self.current_round
            self.negotiation_state["impasse"] = self.check_impasse()  # 更新僵局状态
            
            logging.info(f"\n=== 第 {self.current_round} 轮谈判 ===")
            logging.info(f"剩余时间: {self.negotiation_state['time_remaining']/60:.1f}分钟")
            
            # 提案阶段 - 紧密集成角色方法
            proposal_result = self.proposal_phase()
            if self.check_agreement(proposal_result):
                break
                
            # 还价阶段 - 紧密集成角色方法
            counteroffer_result = self.counteroffer_phase(proposal_result)
            if self.check_agreement(counteroffer_result):
                break
                
            # 顾问建议阶段
            if self.current_round % 2 == 0 or self.negotiation_state["impasse"]:
                self.advice_phase()
                
            # 主持人干预阶段
            if self.negotiation_state["impasse"] or self.current_round >= max_rounds - 1:
                self.intervention_phase()
                
            # 重置角色回合状态
            # self.reset_roles()
            
            self.current_round += 1
            time.sleep(self.delay)
        
        # 结束谈判
        self.conclusion_phase()

    def reset_roles(self):
        """重置所有角色的回合状态"""
        for participant_id, role in self.roles.items():
            if hasattr(role, 'reset_round'):
                role.reset_round = 1  # 重置回合状态
                if role.reset_round == 1:
                    self.logger.debug(f"重置 {role.name} 的回合状态")
                    role.reset_round = 0
                else:
                    logging.info("角色不支持重置回合状态方法")
                
    def start_phase(self) -> None:
        """开始阶段：主持人宣布谈判开始"""
        logging.info("\n=== 谈判开始 ===")
        self.negotiation_state["phase"] = "start"
        
        # 找到主持人
        moderators = [pid for pid, role in self.roles.items() 
                     if isinstance(role, Moderator)]
        
        
        if moderators:
            moderator_id = moderators[0]
            moderator = self.roles[moderator_id]
            agent = self.ai_agents[moderator_id]
            result = agent.start_negotiation(self.negotiation_state)
            
            logging.info(f"\n主持人 {moderator.name} 宣布:")
            logging.info(result["content"])
            
            # 记录开场
            self.negotiation_state["history"].append({
                "round": 0,
                "phase": "start",
                "event": "negotiation_start",
                "moderator": moderator_id,
                "content": result["content"]
            })
            
            # 生成 intervention 和 impasse
            intervention = {
                "type": "start",
                "content": "谈判开始，主持人宣布规则",
                "timestamp": time.time()
            }
            impasse = False  # 假设谈判刚开始，没有僵局

            self._log_intervention(moderator_id, intervention, impasse)
            time.sleep(self.delay)

    def proposal_phase(self) -> Dict:
        """提案阶段：卖家提出提案"""
        logging.info("\n=== 提案阶段 ===")
        self.negotiation_state["phase"] = "proposal"
        
        # 找到卖家
        sellers = [pid for pid, role in self.roles.items() 
                  if isinstance(role, Seller)]
        
        if not sellers:
            raise RuntimeError("谈判中缺少卖家角色")
        
        seller_id = sellers[0]
        seller = self.roles[seller_id]
        agent = self.ai_agents[seller_id]
        
        # 检查卖家是否可以提出报价
        if not seller.can_make_offer(self.current_round):
            logging.info(f"\n{seller.name} 无法提出新报价")
            return {"type": "no_offer", "content": "无法提出新报价"}
        
        # 获取上一轮的还价（如果有）
        last_counteroffer = None
        if self.negotiation_state["offers"]:
            last_offer = self.negotiation_state["offers"][-1]
            if last_offer["event"] == "counter_offer":
                last_counteroffer = last_offer
        
        # 生成提案
        if self.current_round == 1:
            result = agent.make_initial_offer(self.negotiation_state)
            event_type = "initial_offer"
        elif last_counteroffer:
            result = agent.respond_to_counteroffer(self.negotiation_state, last_counteroffer)
            event_type = "counter_response"
        else:
            result = agent.make_new_offer(self.negotiation_state)
            event_type = "new_offer"

        # logging.info("验证：",event_type, result)
        
        # 记录提案到卖家角色
        if "offer" in result:
            offer_accepted = seller.make_offer(result["offer"])
            if not offer_accepted:
                self.logger.warning(f"卖家 {seller.name} 未能记录报价")
        
        logging.info(f"\n卖家 {seller.name} 的提案:")
        logging.info(result["content"])
        # if "offer" in result:
        #     logging.info("提案条款:", json.dumps(result["offer"], indent=2, ensure_ascii=False))
        
        # 记录提案到全局状态
        offer_record = {
            "round": self.current_round,
            "phase": "proposal",
            "event": event_type,
            "proposer": seller_id,
            "content": result["content"],
            "offer": result.get("offer", {}),
            "accept": result.get("accept", False)
        }
        
        self.negotiation_state["offers"].append(offer_record)
        self.negotiation_state["history"].append(offer_record)
        
        if "offer" in result:
            self._log_offer(seller_id, result["offer"])
        
        time.sleep(self.delay)
        return result

    def counteroffer_phase(self, last_offer: Dict) -> Dict:
        """还价阶段：买家回应提案"""
        logging.info("\n=== 还价阶段 ===")
        self.negotiation_state["phase"] = "counteroffer"
        
        # 找到买家
        buyers = [pid for pid, role in self.roles.items() 
                 if isinstance(role, Buyer)]
        
        if not buyers:
            raise RuntimeError("谈判中缺少买家角色")
        
        buyer_id = buyers[0]
        buyer = self.roles[buyer_id]
        agent = self.ai_agents[buyer_id]
        
        # logging.info(f"\nlast_offer:{last_offer}")
        # 检查买家是否可以提出还价
        if not buyer.can_counteroffer(last_offer):
            logging.info(f"\n{buyer.name} 无法提出还价")
            return {"type": "no_counteroffer", "content": "无法提出还价"}
        
        # 买家回应卖家的提案
        result = agent.respond_to_offer(self.negotiation_state, last_offer)
        
        # 记录还价到买家角色
        if "offer" in result:
            counteroffer_accepted = buyer.make_counteroffer(result["offer"])
            if not counteroffer_accepted:
                self.logger.warning(f"买家 {buyer.name} 未能记录还价")
        
        logging.info(f"\n买家 {buyer.name} 的回应:")
        logging.info(result["content"])
        # if "offer" in result:
        #     logging.info("还价条款:", json.dumps(result["offer"], indent=2, ensure_ascii=False))
        
        # 记录还价到全局状态
        counteroffer_record = {
            "round": self.current_round,
            "phase": "counteroffer",
            "event": "counter_offer",
            "proposer": buyer_id,
            "content": result["content"],
            "offer": result.get("offer", {}),
            "accept": result.get("accept", False),
            "response_to": last_offer["proposer"]
        }
        
        self.negotiation_state["offers"].append(counteroffer_record)
        self.negotiation_state["history"].append(counteroffer_record)
        
        if "offer" in result:
            self._log_counteroffer(buyer_id, result["offer"], result.get("accept", False))
        
        time.sleep(self.delay)
        return result

    def advice_phase(self) -> None:
        """顾问建议阶段"""
        logging.info("\n=== 顾问建议 ===")
        self.negotiation_state["phase"] = "advice"
        
        # 找到顾问
        advisors = [pid for pid, role in self.roles.items() 
                   if isinstance(role, Advisor)]
        
        for advisor_id in advisors:
            advisor = self.roles[advisor_id]
            agent = self.ai_agents[advisor_id]
            
            # 获取最新的提案
            last_offer = None
            if self.negotiation_state["offers"]:
                last_offer = self.negotiation_state["offers"][-1]
            
            if last_offer:
                # 确定顾问的服务对象
                recipient_id = None
                if advisor.client_type == "seller":
                    sellers = [pid for pid, role in self.roles.items() 
                              if isinstance(role, Seller)]
                    if sellers:
                        recipient_id = sellers[0]
                elif advisor.client_type == "buyer":
                    buyers = [pid for pid, role in self.roles.items() 
                             if isinstance(role, Buyer)]
                    if buyers:
                        recipient_id = buyers[0]
                
                if recipient_id:
                    # 检查顾问是否可以提供建议
                    if not advisor.can_advise(self.current_round):
                        logging.info(f"\n顾问 {advisor.name} 无法提供建议")
                        continue
                    
                    result = agent.provide_advice(self.negotiation_state, last_offer)
                    
                    # 记录建议到顾问角色
                    advice_accepted = advisor.give_advice({
                        "round": self.current_round,
                        "recipient": recipient_id,
                        "content": result["content"]
                    })
                    if not advice_accepted:
                        self.logger.warning(f"顾问 {advisor.name} 未能记录建议")
                    
                    logging.info(f"\n{advisor.expertise}顾问 {advisor.name} 给 {self.roles[recipient_id].name} 的建议:")
                    logging.info(result["content"])
                    
                    # 记录建议到全局状态
                    advice_record = {
                        "round": self.current_round,
                        "phase": "advice",
                        "event": "advisor_advice",
                        "advisor": advisor_id,
                        "recipient": recipient_id,
                        "content": result["content"]
                    }
                    
                    self.negotiation_state["history"].append(advice_record)
                    self._log_advice(advisor_id, result["content"], recipient_id)
                    
                    time.sleep(self.delay)

    def intervention_phase(self) -> None:
        """主持人干预阶段"""
        logging.info("\n=== 主持人干预 ===")
        self.negotiation_state["phase"] = "intervention"
        
        # 找到主持人
        moderators = [pid for pid, role in self.roles.items() 
                     if isinstance(role, Moderator)]
        
        if moderators:
            moderator_id = moderators[0]
            moderator = self.roles[moderator_id]
            agent = self.ai_agents[moderator_id]
            
            # 检查主持人是否可以干预
            if not moderator.can_intervene(self.current_round, self.negotiation_state["impasse"]):
                logging.info(f"\n主持人 {moderator.name} 无法干预")
                return
                
            result = agent.manage_process(self.negotiation_state)
            
            # 记录干预到主持人角色
            intervention_accepted = moderator.intervene({
                "round": self.current_round,
                "content": result["content"],
                "impasse": self.negotiation_state["impasse"]
            })
            if not intervention_accepted:
                self.logger.warning(f"主持人 {moderator.name} 未能记录干预")
            
            logging.info(f"\n主持人 {moderator.name} 的干预:")
            logging.info(result["content"])
            
            # 记录干预到全局状态
            intervention_record = {
                "round": self.current_round,
                "phase": "intervention",
                "event": "moderator_intervention",
                "moderator": moderator_id,
                "content": result["content"]
            }
            
            self.negotiation_state["history"].append(intervention_record)
            self._log_intervention(moderator_id, result["content"], self.negotiation_state["impasse"])
            self.negotiation_state["impasse"] = False  # 干预后重置僵局状态
            # 更新谈判状态
            self.negotiation_state["time_remaining"] = max(0, self.negotiation_state["time_remaining"] - 300)
            time.sleep(self.delay)


    def conclusion_phase(self) -> None:
        """结束阶段：主持人宣布谈判结果"""
        logging.info("\n=== 谈判结束 ===")
        self.negotiation_state["phase"] = "conclusion"
        
        # 找到主持人
        moderators = [pid for pid, role in self.roles.items() 
                     if isinstance(role, Moderator)]
        
        if moderators:
            moderator_id = moderators[0]
            agent = self.ai_agents[moderator_id]
            
            # 获取最终协议（如果有）
            agreement = None
            if self.negotiation_state["agreement_reached"]:
                agreement = self.negotiation_state["agreement_details"]
            
            result = agent.conclude_negotiation(self.negotiation_state, agreement)
            
            logging.info(f"\n主持人 {self.roles[moderator_id].name} 宣布最终结果:")
            logging.info(result["content"])
            
            # 记录结论
            conclusion_record = {
                "round": self.current_round,
                "phase": "conclusion",
                "event": "negotiation_conclusion",
                "moderator": moderator_id,
                "content": result["content"],
                "agreement_reached": self.negotiation_state["agreement_reached"]
            }
            
            if self.negotiation_state["agreement_reached"]:
                conclusion_record["agreement_details"] = self.negotiation_state["agreement_details"]
                self.log_agreement(self.negotiation_state["agreement_details"],roles=list(self.negotiation_state["roles"].keys()))
            
            self.negotiation_state["history"].append(conclusion_record)
            
            time.sleep(self.delay)

    def check_agreement(self, offer_result: Dict) -> bool:
        """检查是否达成协议"""
        if offer_result.get("accept", False):
            self.negotiation_state["agreement_reached"] = True
            self.negotiation_state["agreement_details"] = offer_result.get("content", {})
            logging.info("\n=== 达成协议 ===")
            # logging.info("协议条款:", json.dumps(offer_result["content"], indent=2, ensure_ascii=False))
            # logging.info("协议条款: %s", json.dumps(offer_result["content"], indent=2, ensure_ascii=False))
            return True
        return False

    def check_impasse(self) -> bool:
        """检查是否陷入僵局"""
        # 简单实现：连续2轮提案没有进展
        if len(self.negotiation_state["offers"]) < 3:
            return False
            
        last_two = self.negotiation_state["offers"][-2:]
        progress = False
        
        # 检查是否有价格变化
        for offer in last_two:
            if "offer" in offer and offer["offer"].get("price"):
                # 如果有价格变化，视为有进展
                progress = True
                break
        
        # 如果没有进展，判定为僵局
        if not progress:
            # 更新谈判状态
            self.negotiation_state["impasse"] = True
            
            # 记录僵局原因
            reason = "连续2轮价格没有变化"
            self._log_impasse(reason)
            
            logging.info("\n=== 谈判僵局 ===")
            logging.info(f"原因: {reason}")
            return True      
        return False

    def check_negotiation_end(self) -> bool:
        """检查谈判是否应该结束"""
        max_rounds = self.negotiation_state.get("max_rounds", 5)
        
        # 检查是否达成协议
        if self.negotiation_state["agreement_reached"]:
            logging.info("\n=== 达成协议，谈判结束 ===")
            return True
            
        # 检查是否超过最大轮次
        if self.current_round >= max_rounds:
            logging.info("\n=== 达到最大轮次，谈判结束 ===")
            self._log_impasse("达到最大轮次")
            return True
            
        # 检查是否超时
        if self.negotiation_state.get("time_remaining", 1800) <= 0:
            logging.info("\n=== 时间用完，谈判结束 ===")
            self._log_impasse("时间用完")
            return True
            
        # 检查是否陷入僵局（可选）
        if self.negotiation_state.get("impasse", False):
            logging.info("\n=== 谈判陷入僵局，无法继续 ===")
            return True
            
        return False