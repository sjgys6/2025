from enum import Enum
from typing import Optional, Dict, List
import logging

class RoleType(Enum):
    SELLER = "seller"        # 卖家
    BUYER = "buyer"          # 买家
    ADVISOR = "advisor"      # 顾问
    MODERATOR = "moderator"  # 主持人

class BaseRole:
    def __init__(self, player_id: str, name: str, role_type: RoleType):
        self.player_id = player_id
        self.name = name
        self.role_type = role_type
        self.negotiation_ready = True  # 是否准备好参与谈判
        self.logger = logging.getLogger(__name__)
        self.negotiation_history = []  # 谈判历史记录

    def is_seller(self) -> bool:
        """判断是否是卖家"""
        return self.role_type == RoleType.SELLER

    def is_buyer(self) -> bool:
        """判断是否是买家"""
        return self.role_type == RoleType.BUYER

    def record_negotiation(self, event: Dict) -> None:
        """记录谈判事件"""
        self.negotiation_history.append(event)
        self.logger.debug(f"记录谈判事件: {event.get('type')}")

class Seller(BaseRole):
    def __init__(self, player_id: str, name: str, min_price: float, target_price: float, delivery_days: int):
        super().__init__(player_id, name, RoleType.SELLER)
        self.min_price = min_price         # 最低可接受价格
        self.target_price = target_price    # 目标成交价格
        self.delivery_days = delivery_days  # 可接受的交货天数
        self.current_offer: Optional[Dict] = None  # 当前报价
        self.previous_offers: List[Dict] = []  # 历史报价

    def can_make_offer(self, negotiation_round: int) -> bool:
        """检查是否可以提出新报价
        
        Args:
            negotiation_round: 当前谈判轮次
            
        Returns:
            bool: 是否可以提出新报价
        """
        if not self.negotiation_ready:
            self.logger.debug("卖家未准备好，无法提出报价")
            return False
        # 检查是否已经提出过报价（除第一轮外）
        if negotiation_round > 1 and not self.previous_offers:
            self.logger.debug("卖家尚未回应买家还价")
            return False
        return True

    def make_offer(self, offer: Dict) -> bool:
        """记录新报价
        
        Args:
            offer: 报价内容，包含价格、交货期等
            
        Returns:
            bool: 是否成功记录报价
        """
        if not self.can_make_offer(offer.get("round", 0)):
            return False
            
        self.current_offer = offer
        self.previous_offers.append(offer)
        self.logger.info(f"卖家提出报价: {offer}")
        return True

class Buyer(BaseRole):
    def __init__(self, player_id: str, name: str, max_price: float, target_price: float, required_delivery: int):
        super().__init__(player_id, name, RoleType.BUYER)
        self.max_price = max_price          # 最高可接受价格
        self.target_price = target_price    # 目标成交价格
        self.required_delivery = required_delivery  # 要求的交货天数
        self.current_counteroffer: Optional[Dict] = None  # 当前还价
        self.previous_counteroffers: List[Dict] = []  # 历史还价

    def can_counteroffer(self, seller_offer: Dict) -> bool:
        """检查是否可以提出还价
        
        Args:
            seller_offer: 卖家的最新报价
            
        Returns:
            bool: 是否可以提出还价
        """
        # logging.info("seller_offer:",seller_offer)
        if not self.negotiation_ready:
            self.logger.debug("买家未准备好，无法提出还价")
            logging.info("买家未准备好，无法提出还价")
            return False
        # if not seller_offer:
        #     self.logger.debug("尚未收到卖家报价，无法还价")
        #     logging.info("尚未收到卖家报价，无法还价")
        #     return False
        
        # 检查卖家报价是否有效
        # if "price" not in seller_offer or "delivery" not in seller_offer:
        #     self.logger.debug("卖家报价无效，无法还价")
        #     logging.info("卖家报价无效，无法还价")
        #     return False
        return True

    def make_counteroffer(self, counteroffer: Dict) -> bool:
        """记录新还价
        
        Args:
            counteroffer: 还价内容
            
        Returns:
            bool: 是否成功记录还价
        """
        if not self.can_counteroffer(counteroffer.get("response_to")):
            return False
            
        self.current_counteroffer = counteroffer
        self.previous_counteroffers.append(counteroffer)
        self.logger.info(f"买家提出还价: {counteroffer}")
        return True

class Advisor(BaseRole):
    def __init__(self, player_id: str, name: str, client_type: str, expertise: str):
        """
        Args:
            client_type: 服务对象类型 (seller/buyer)
            expertise: 专业领域 (法律/财务/技术等)
        """
        super().__init__(player_id, name, RoleType.ADVISOR)
        self.client_type = client_type
        self.expertise = expertise
        self.advice_given = False  # 本轮是否已提供建议
        self.advice_history: List[Dict] = []  # 建议历史

    def can_advise(self, negotiation_round: int) -> bool:
        """检查是否可以提供建议
        
        Args:
            negotiation_round: 当前谈判轮次
            
        Returns:
            bool: 是否可以提供建议
        """
        if not self.negotiation_ready:
            self.logger.debug("顾问未准备好，无法提供建议")
            logging.info("顾问未准备好，无法提供建议")
            return False
        if self.advice_given:
            self.logger.debug("本轮已提供过建议")
            logging.info("本轮已提供过建议")
            return False
        # 顾问通常在关键轮次或僵局时提供建议
        if negotiation_round < 2:
            self.logger.debug("谈判初期，暂不需要建议")
            logging.info("谈判初期，暂不需要建议")
            return False
        return True

    def give_advice(self, advice: Dict) -> bool:
        """记录提供的建议
        
        Args:
            advice: 建议内容
            
        Returns:
            bool: 是否成功记录建议
        """
        if not self.can_advise(advice.get("round", 0)):
            return False
            
        self.advice_history.append(advice)
        self.advice_given = True
        self.logger.info(f"{self.expertise}顾问提供建议: {advice}")
        return True

    def reset_round(self) -> None:
        """重置回合状态"""
        self.advice_given = False

class Moderator(BaseRole):
    def __init__(self, player_id: str, name: str, rules: Dict, client_type: str = None, compromising_party: str = None):
        """
        Args:
            rules: 谈判规则，包含时间限制、轮次限制等
        """
        super().__init__(player_id, name, RoleType.MODERATOR)
        self.rules = rules
        self.client_type = client_type 
        self.compromising_party = compromising_party  
        self.intervention_used = False  # 本轮是否已进行干预
        self.intervention_history: List[Dict] = []  # 干预历史

    def can_intervene(self, negotiation_round: int, impasse: bool) -> bool:
        """检查是否可以干预谈判
        
        Args:
            negotiation_round: 当前谈判轮次
            impasse: 是否处于僵局状态
            
        Returns:
            bool: 是否可以干预谈判
        """
        if not self.negotiation_ready:
            self.logger.debug("主持人未准备好，无法干预")
            logging.info("主持人未准备好，无法干预")
            return False
        # if self.intervention_used:
        #     self.logger.debug("本轮已进行过干预")
        #     logging.info("本轮已进行过干预")
        #     return False
        # 主持人在僵局或关键轮次干预
        if impasse or negotiation_round >= self.rules.get("max_rounds", 5) - 1:
            return True
        return False

    def intervene(self, intervention: Dict) -> bool:
        """记录干预行动
        
        Args:
            intervention: 干预内容
            
        Returns:
            bool: 是否成功记录干预
        """
        if not self.can_intervene(intervention.get("round", 0), intervention.get("impasse", False)):
            return False
            
        self.intervention_history.append(intervention)
        self.intervention_used = True
        self.logger.info(f"主持人进行干预: {intervention}")
        return True

    def reset_round(self) -> None:
        """重置回合状态"""
        self.intervention_used = False