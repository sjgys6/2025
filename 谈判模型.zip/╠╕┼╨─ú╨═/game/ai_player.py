"""
AI 玩家系统

主要功能：
1. 统一的 AI 代理接口
2. 区分买家、卖家、顾问和主持人的代理
3. 维护对话历史和游戏状态记忆
4. 统一使用 OpenAI API 进行调用
"""

from typing import Optional, Dict, Any, List
import openai
import logging
import re
from .roles import BaseRole, RoleType
import random
import json

class NegotiationMemory:
    def __init__(self):
        self.negotiation_history: List[Dict] = []  # 所有谈判记录
        self.game_results: List[Dict] = []   # 游戏结果
        self.current_round_offers: List[Dict] = []  # 当前回合的报价记录

    def add_negotiation(self, record: Dict):
        """添加谈判记录
        
        Args:
            record: 包含回合、阶段、谈判者、内容和条款的字典
        """
        self.negotiation_history.append(record)
        if record.get("phase") in ["offer", "counter_offer"]:
            self.current_round_offers.append(record)

    def add_game_result(self, result: Dict):
        """添加游戏结果"""
        self.game_results.append(result)

    def get_current_round_offers(self) -> List[Dict]:
        """获取当前回合的所有报价记录"""
        return self.current_round_offers

    def clear_current_round(self):
        """清空当前回合的谈判记录"""
        self.current_round_offers = []

    def get_recent_negotiations(self, count: int = 3) -> str:
        """获取最近的几条谈判记录，格式化为易读字符串"""
        if not self.negotiation_history:
            return "暂无谈判记录"
            
        recent = self.negotiation_history[-count:]
        formatted = []
        
        for record in recent:
            phase = record.get("phase", "未知阶段")
            speaker = record.get("proposer", "未知谈判者")
            content = record.get("content", "")
            offer = record.get("offer", {})
            
            if phase == "offer":
                formatted.append(f"【开局提案】{speaker}：{content}")
                if offer:
                    formatted.append(f"    >> 条款：{json.dumps(offer, ensure_ascii=False)}")
            elif phase == "counter_offer":
                formatted.append(f"【还价回应】{speaker} 回应 {record.get('response_to', '对方')}：{content}")
                if offer:
                    formatted.append(f"    >> 新条款：{json.dumps(offer, ensure_ascii=False)}")
            elif phase == "advice":
                formatted.append(f"【专业建议】{speaker} 给 {record.get('for', '客户')}：{content}")
            elif phase == "intervention":
                formatted.append(f"【主持人干预】{speaker}：{content}")
            elif phase == "accept":
                formatted.append(f"【达成协议】{speaker} 接受了提案")
        
        return "\n".join(formatted)

    def get_full_history(self) -> str:
        """获取完整谈判历史的格式化字符串"""
        if not self.negotiation_history:
            return "暂无谈判历史记录"
            
        formatted = []
        current_round = None
        
        for record in self.negotiation_history:
            # 如果是新的回合，添加回合标记
            if current_round != record.get("round"):
                current_round = record.get("round")
                formatted.append(f"\n=== 第 {current_round} 回合 ===\n")
            
            phase = record.get("phase", "未知阶段")
            speaker = record.get("proposer", "未知谈判者")
            content = record.get("content", "")
            offer = record.get("offer", {})
            
            if phase == "offer":
                formatted.append(f"{speaker} 开局提案：{content}")
                if offer:
                    formatted.append(f"    提案条款：{json.dumps(offer, ensure_ascii=False)}")
            elif phase == "counter_offer":
                formatted.append(f"{speaker} 回应 {record.get('response_to', '对方')}：{content}")
                if offer:
                    formatted.append(f"    还价条款：{json.dumps(offer, ensure_ascii=False)}")
            elif phase == "advice":
                formatted.append(f"{speaker} 给 {record.get('for', '客户')} 的建议：{content}")
            elif phase == "intervention":
                formatted.append(f"主持人 {speaker} 干预：{content}")
            elif phase == "accept":
                formatted.append(f"【达成协议】{speaker} 接受了提案")
        
        return "\n".join(formatted)

    def get_history(self) -> List[Dict]:
        """获取原始谈判历史记录"""
        return self.negotiation_history

class BaseAIAgent:
    def __init__(self, config: Dict[str, Any], role: BaseRole):
        self.config = config
        self.role = role  # 包含谈判者身份和目标
        self.logger = logging.getLogger(__name__)
        self.memory = NegotiationMemory()  # 专门记录谈判历史
        self.client = openai.OpenAI(
            api_key="sk-YCTC2bBCuyjxKkVvCcDe2dFa64Aa4012A8Bd0544A05bE5C9",
            base_url="https://api.toiotech.com/v1"
        )
        # self.min_demand = role.min_demand  # 最低可接受条件
        # self.target_value = role.target_value  # 理想目标值

    def ask_ai(self, prompt: str, system_prompt: str = None) -> str:
        """统一的 AI 调用接口"""
        try:
            messages = []

            game_note = f"请注意，这是一场零和博弈，所有行为应基于博弈思维进行。"

            if system_prompt:
                system_prompt = f"{game_note}\n{system_prompt}"
            else:
                system_prompt = game_note
        
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.chat.completions.create(
                model=self.config["model"],
                messages=messages
            )
            return response.choices[0].message.content
        except Exception as e:
            self.logger.error(f"AI 调用失败: {str(e)}")
            return "【陷入沉思】我需要时间重新思考这个提案"

    def _extract_offer(self, response: str) -> Optional[Dict]:
        """从 AI 响应中提取出价内容
        
        Args:
            response: AI的完整响应文本
        
        Returns:
            dict: 解析出的出价条款，如 {"price": 500, "delivery": 30}
        """
        try:
            # 尝试解析结构化JSON
            json_pattern = r'\{[\s\S]*?\}'
            json_match = re.search(json_pattern, response)
            if json_match:
                try:
                    return json.loads(json_match.group(0))
                except json.JSONDecodeError:
                    pass
            
            # 模式匹配常见谈判条款
            patterns = {
                "price": r'(价格|金额|报价)[：:]\s*(\d+[\d,]*\.?\d*)',
                "quantity": r'(数量|件数)[：:]\s*(\d+[\d,]*)',
                "delivery": r'(交付|交货)[：:]\s*(\d+)\s*天',
                "payment": r'(付款|支付)[：:]\s*(\w+期)'
            }
            
            offer = {}
            for term, pattern in patterns.items():
                match = re.search(pattern, response)
                if match:
                    offer[term] = match.group(2)
            
            return offer if offer else None
        
        except Exception as e:
            self.logger.error(f"提取出价时出错: {str(e)}")
            return None

    def open_negotiation(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """开启谈判，提出初始方案"""
        prompt = self._generate_opening_prompt(game_state)
        response = self.ask_ai(prompt, self._get_negotiator_prompt())
        
        # 解析出价内容
        offer = self._extract_offer(response) or {}
        
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "opening",
            "proposer": self.role.name,
            "content": response,
            "offer": offer
        })
        
        return {
            "type": "offer",
            "proposer": self.role.name,
            "content": response,
            "offer": offer
        }

    def respond_to_offer(self, game_state: Dict[str, Any], last_offer: Dict) -> Dict[str, Any]:
        """回应对方的提案"""
        prompt = self._generate_response_prompt(game_state, last_offer)
        response = self.ask_ai(prompt, self._get_response_prompt())
        
        # 解析出价内容
        counter_offer = self._extract_offer(response) or {}
        
        # 检测是否接受
        is_accept = self._detect_acceptance(response)
        
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "counter",
            "proposer": self.role.name,
            "content": response,
            "offer": counter_offer,
            "response_to": last_offer["proposer"]
        })
        
        return {
            "type": "counter_offer" if not is_accept else "accept",
            "content": response,
            "proposer": self.role.name,
            "offer": counter_offer,
            "accept": is_accept
        }

    def _generate_action_prompt(self) -> str:
        """生成谈判动作和神态的提示词"""
        return """
        请在谈判发言时加入动作和表情描写，要求：
        1. 用【】包裹动作和表情
        2. 展现谈判中的心理活动和情绪变化
        3. 表现出专业谈判者的风范
        4. 包含至少15字的非语言行为描写
        5. 符合你的谈判身份和立场
        """

    def _format_negotiation_history(self, history: List[Dict]) -> str:
        """格式化谈判历史记录"""
        if not history:
            return "暂无谈判记录"
        
        formatted = []
        for record in history:
            action = "提议" if record["phase"] == "opening" else "回应"
            formatted.append(f"{record['proposer']} {action}: {record['content']}")
            if record["offer"]:
                formatted.append(f"    >> 条款: {json.dumps(record['offer'], ensure_ascii=False)}")
        return "\n".join(formatted)

    def _get_negotiator_prompt(self) -> str:
        """获取谈判者的系统提示词"""
        return f"""
        你是一名专业的谈判代表，代表{self.role.organization}。
        你的目标：
        - 核心诉求: {self.role.core_demand}
        - 最低接受条件: {self.min_demand}
        - 理想目标: {self.target_value}
        
        谈判策略：
        1. 开局提出高于预期的要求
        2. 逐步让步但要显得勉强
        3. 寻找双赢解决方案
        4. 保持专业但必要时展现情绪
        5. 永远不要直接暴露底线
        """

    def _get_response_prompt(self) -> str:
        return f"""
        你正在回应对方的提案，需要：
        1. 评估对方提案与己方目标的差距
        2. 决定是否接受、拒绝还是还价
        3. 若拒绝需给出合理解释
        4. 若还价要提供替代方案
        5. 使用专业谈判话术
        6. 记住你的底线: {self.min_demand}
        """

    def _detect_acceptance(self, response: str) -> bool:
        """检测响应中是否包含接受信号"""
        accept_phrases = [
            "接受此方案", "同意该提案", "可以接受", "达成协议",
            "我们成交", "就这样定了", "原则上同意"
        ]
        return any(phrase in response for phrase in accept_phrases)

    def _generate_opening_prompt(self, game_state: Dict[str, Any]) -> str:
        """生成开局谈判提示词"""
        return f"""
        {self._generate_action_prompt()}
        
        谈判背景:
        - 议题: {game_state['negotiation_topic']}
        - 参与方: {', '.join(game_state['roles'])}
        - 你的身份: {self.role.organization}代表 {self.role.name}
        - 你的授权: {self.role.authority_level}
        
        历史谈判:
        {self._format_negotiation_history(self.memory.get_history())}
        
        请准备你的开场提案：
        1. 提出略高于预期的初始要求
        2. 包含至少3个关键条款
        3. 使用专业谈判话术
        4. 保持开放但坚定的态度
        5. 发言要超过80字
        6. 最后用JSON格式总结你的提案
        """

    def _generate_response_prompt(self, game_state: Dict[str, Any], last_offer: Dict) -> str:
        """生成回应提案的提示词"""
        return f"""
        {self._generate_action_prompt()}
        
        最新提案来自 {last_offer['proposer']}:
        {last_offer['content']}
        
        提案条款:
        {json.dumps(last_offer.get('offer', {}), ensure_ascii=False, indent=2)}
        
        你的谈判目标:
        - 核心需求: {self.role.core_demand}
        - 理想目标: {self.target_value}
        - 最低接受条件: {self.min_demand}
        
        谈判背景:
        - 已进行回合: {game_state['current_round']}/{game_state['max_rounds']}
        - 剩余时间: {game_state['time_remaining']}分钟
        
        历史谈判:
        {self._format_negotiation_history(self.memory.get_history())}
        
        请回应上述提案：
        1. 分析对方提案与己方目标的差距
        2. 决定接受、拒绝还是提出反提案
        3. 若拒绝需给出专业解释
        4. 若反提案要包含让步和交换条件
        5. 发言要超过100字
        6. 最后用JSON格式总结你的提案
        """
    
class SellerAgent(BaseAIAgent):
    def __init__(self, config: Dict[str, Any], role: BaseRole):
        super().__init__(config, role)
        self.min_price = role.min_price  # 最低可接受价格
        self.target_price = role.target_price  # 理想目标价格
        self.delivery_days = role.delivery_days  # 可接受交付天数范围

    def make_initial_offer(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """卖家提出初始报价"""
        prompt = self._generate_initial_offer_prompt(game_state)
        response = self.ask_ai(prompt, self._get_seller_prompt())
        
        # 解析报价内容
        offer = self._extract_offer(response) or {}
        
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "initial_offer",
            "proposer": self.role.name,
            "content": response,
            "offer": offer,
            "accept": False  # 初始报价通常不接受
        })
        
        return {
            "type": "offer",
            "content": response,
            "offer": offer,
            "proposer": self.role.name,
            "accept": False  # 初始报价通常不接受
        }

    def respond_to_counteroffer(self, game_state: Dict[str, Any], counteroffer: Dict) -> Dict[str, Any]:
        """回应买家的还价"""
        prompt = self._generate_response_prompt(game_state, counteroffer)
        response = self.ask_ai(prompt, self._get_seller_response_prompt())
        
        # 解析还价内容
        counter = self._extract_offer(response) or {}
        
        # 检测是否接受
        is_accept = self._detect_acceptance(response)
        
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "counter",
            "proposer": self.role.name,
            "content": response,
            "offer": counter,
            "response_to": counteroffer["proposer"],
            "accept": is_accept
        })
        
        return {
            "type": "counter_offer" if not is_accept else "accept",
            "content": response,
            "offer": counter,
            "proposer": self.role.name,
            "accept": is_accept
        }
    
    def make_new_offer(self, game_state):
        """
        买家生成新的提案
        :param game_state: 当前谈判状态
        :return: 包含提案的字典
        """
        # 获取当前轮次
        current_round = game_state.get("current_round", 0)

        # 基于谈判状态生成新的提案
        new_offer = {
            "price": max(10, game_state.get("last_offer", {}).get("price", 20) - 2),  # 降低价格
            "delivery_days": min(30, game_state.get("last_offer", {}).get("delivery_days", 15) + 1)  # 放宽交付时间
        }

        # 记录提案到谈判历史
        self.memory.add_negotiation({
            "round": current_round,
            "phase": "new_offer",
            "proposer": self.role.name,
            "content": new_offer
        })

        # 返回提案
        return {"offer": new_offer}

    def _get_seller_prompt(self) -> str:
        """获取卖家的系统提示词"""
        return f"""
        你是一名专业的卖家，销售古董。
        你的目标：
        - 最低可接受价格: ¥{self.min_price}
        - 理想目标价格: ¥{self.target_price}
        - 最快可接受交付天数: {self.delivery_days}天
        
        谈判策略：
        1. 开局提出高于预期的报价
        2. 逐步让步但要显得勉强
        3. 强调产品质量和优势
        4. 保持专业但必要时展现情绪
        5. 永远不要直接暴露底价
        """

    def _get_seller_response_prompt(self) -> str:
        return f"""
        你正在回应买家的提案，需要：
        1. 评估买方提案与己方目标的差距
        2. 决定是否接受、拒绝还是还价
        3. 若拒绝需给出合理解释
        4. 若还价要提供替代方案
        5. 使用专业谈判话术
        6. 记住你的理想售价: ¥{self.min_price}，但为了获得更好的交易，可以适当让步
        7. 记住，适时的让步并不意味着一件坏事
        """

    def _generate_initial_offer_prompt(self, game_state: Dict[str, Any]) -> str:
        """生成初始报价提示词"""
        return f"""
        {self._generate_action_prompt()}
        
        谈判背景:
        - 产品: {game_state['product']}
        - 买家: {game_state['Buyer']}
        - 你的身份: {self.role.name}
        
        请准备你的初始报价：
        1. 提出略高于预期的价格
        2. 包含至少3个关键条款（价格、数量、交付期等）
        3. 突出产品优势和卖点
        4. 使用专业谈判话术
        5. 最后用JSON格式总结你的提案
        """

    def _generate_response_prompt(self, game_state: Dict[str, Any], counteroffer: Dict) -> str:
        """生成回应提案的提示词"""
        return f"""
        {self._generate_action_prompt()}
        
        买家 {counteroffer['proposer']} 的还价:
        {counteroffer['content']}
        
        还价条款:
        {json.dumps(counteroffer.get('offer', {}), ensure_ascii=False, indent=2)}
        
        你的谈判目标:
        - 价格起点(最高): ¥{self.target_price * 2}
        - 最低价格: ¥{self.min_price}
        - 理想价格: ¥{self.target_price}
        - 可接受交付天数: {self.delivery_days}天
        
        谈判背景:
        - 已进行回合: {game_state['current_round']}/{game_state['max_rounds']}
        - 剩余时间: {game_state['time_remaining']}分钟
        
        历史谈判:
        {self._format_negotiation_history(self.memory.get_history())}
        
        请回应上述还价：
        1. 分析对方提案与己方目标的差距
        2. 决定接受、拒绝还是提出反提案
        3. 若拒绝需给出专业解释
        4. 若反提案要包含让步和交换条件
        5. 最后用JSON格式总结你的提案
        """


class BuyerAgent(BaseAIAgent):
    def __init__(self, config: Dict[str, Any], role: BaseRole):
        super().__init__(config, role)
        self.max_price = role.max_price  # 最高可接受价格
        self.target_price = role.target_price  # 理想目标价格
        self.required_delivery = role.required_delivery  # 要求交付天数

    def make_counteroffer(self, game_state: Dict[str, Any], initial_offer: Dict) -> Dict[str, Any]:
        """买家提出还价"""
        prompt = self._generate_counteroffer_prompt(game_state, initial_offer)
        response = self.ask_ai(prompt, self._get_buyer_prompt())
        
        # 解析还价内容
        counter = self._extract_offer(response) or {}
        
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "counter",
            "proposer": self.role.name,
            "content": response,
            "offer": counter,
            "response_to": initial_offer["proposer"]
        })
        
        return {
            "type": "counter_offer",
            "content": response,
            "offer": counter
        }

    def respond_to_offer(self, game_state: Dict[str, Any], offer: Dict) -> Dict[str, Any]:
        """回应卖家的新提案"""
        prompt = self._generate_response_prompt(game_state, offer)
        response = self.ask_ai(prompt, self._get_buyer_response_prompt())
        
        # 解析还价内容
        counter = self._extract_offer(response) or {}
        
        # 检测是否接受
        is_accept = self._detect_acceptance(response)

        # print(offer)
        # 记录谈判历史 - 修改这里
        phase_type = "counter_offer" if not is_accept else "accept"
        # 记录谈判历史
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": phase_type,
            "proposer": self.role.name,
            "content": response,
            "offer": counter,
            "response_to": offer["proposer"],
            "accept": is_accept
        })
        
        # print("熊二的回应",{
        #     "type": phase_type,
        #     "content": response,
        #     "proposer": self.role.name,
        #     "offer": counter,
        #     "accept": is_accept
        # })

        return {
            "type": phase_type,
            "content": response,
            "proposer": self.role.name,
            "offer": counter,
            "accept": is_accept
        }

    def _get_buyer_prompt(self) -> str:
        """获取买家的系统提示词"""
        return f"""
        你是一名专业的采购代表，为{self.role.company}采购{self.role.product}。
        你的目标：
        - 最高可接受价格: ¥{self.max_price}
        - 理想目标价格: ¥{self.target_price}
        - 最慢要求交付天数: {self.required_delivery}天
        
        谈判策略：
        1. 开局提出低于预期的还价
        2. 逐步提高但要显得勉强
        3. 强调预算限制和市场行情
        4. 利用竞争关系施加压力
        5. 永远不要直接暴露最高预算
        """

    def _get_buyer_response_prompt(self) -> str:
        return f"""
        你正在回应卖家的提案，需要：
        1. 评估卖方提案与己方目标的差距
        2. 决定是否接受、拒绝还是还价
        3. 若拒绝需指出不合理之处
        4. 若还价要提供替代方案
        5. 使用专业谈判话术
        6. 记住你的理想预算上限: ¥{self.max_price}，但为了获得更好的交易，可以适当让步
        7. 记住，适时的让步并不意味着一件坏事
        """

    def _generate_counteroffer_prompt(self, game_state: Dict[str, Any], initial_offer: Dict) -> str:
        """生成还价提示词"""
        return f"""
        {self._generate_action_prompt()}
        
        卖家 {initial_offer['proposer']} 的初始报价:
        {initial_offer['content']}
        
        报价条款:
        {json.dumps(initial_offer.get('offer', {}), ensure_ascii=False, indent=2)}
        
        你的谈判目标:
        - 最高价格: ¥{self.max_price}
        - 理想价格: ¥{self.target_price}
        - 要求交付天数: {self.required_delivery}天内
        
        请准备你的还价：
        1. 提出低于预期的价格
        2. 包含至少3个关键条款
        3. 强调预算限制和市场行情
        4. 使用专业谈判话术
        5. 最后用JSON格式总结你的提案
        """

    def _generate_response_prompt(self, game_state: Dict[str, Any], offer: Dict) -> str:
        """生成回应提案的提示词"""
        # print(f"Generating response prompt for offer: {offer}")
        return f"""
        {self._generate_action_prompt()}
        
        卖家 熊大 的新提案:
        {offer['content']}
        
        提案条款:
        {json.dumps(offer.get('offer', {}), ensure_ascii=False, indent=2)}
        
        你的谈判目标:
        - 最高价格: ¥{self.max_price}
        - 理想价格: ¥{self.target_price}
        - 要求交付天数: {self.required_delivery}天内
        
        谈判背景:
        - 已进行回合: {game_state['current_round']}/{game_state['max_rounds']}
        - 剩余时间: {game_state['time_remaining']}分钟
        
        历史谈判:
        {self._format_negotiation_history(self.memory.get_history())}
        
        请回应上述提案：
        1. 分析对方提案与己方目标的差距
        2. 决定接受、拒绝还是提出反提案
        3. 若拒绝需指出不合理之处
        4. 若反提案要包含让步和交换条件
        5. 最后用JSON格式总结你的提案
        """

class AdvisorAgent(BaseAIAgent):
    def __init__(self, config: Dict[str, Any], role: BaseRole):
        super().__init__(config, role)
        self.client_type = role.client_type  # 服务对象类型（买家/卖家）
        self.expertise = role.expertise  # 专业领域

    def provide_advice(self, game_state: Dict[str, Any], negotiation_data: Dict) -> Dict[str, Any]:
        """提供专业建议"""
        prompt = self._generate_advice_prompt(game_state, negotiation_data)
        response = self.ask_ai(prompt, self._get_advisor_prompt())
        
        # 记录建议
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "advice",
            "advisor": self.role.name,
            "content": response,
            "for": negotiation_data["proposer"]
        })
        
        return {
            "type": "advice",
            "content": response,
            "for": negotiation_data["proposer"]
        }

    def _get_advisor_prompt(self) -> str:
        """获取顾问的系统提示词"""
        return f"""
        你是一名专业的{self.expertise}顾问，为{self.client_type}提供谈判支持。
        你的角色：
        1. 分析当前谈判局势
        2. 指出对方提案的优缺点
        3. 建议最佳应对策略
        4. 提供专业领域知识支持
        5. 保持客观中立态度
        
        专业领域:
        - {self.expertise}
        - 市场行情分析
        - 风险评估
        - 替代方案建议
        """

    def _generate_advice_prompt(self, game_state: Dict[str, Any], negotiation_data: Dict) -> str:
        """生成建议提示词"""
        return f"""
        当前谈判状态:
        - 回合: {game_state['current_round']}
        - 剩余时间: {game_state['time_remaining']}分钟
        - 谈判双方: {"熊大(卖家)", "熊二(买家)"}
        
        最新提案:
        - 提案方: {negotiation_data['proposer']}
        - 内容: {negotiation_data['content']}
        - 条款: {json.dumps(negotiation_data.get('offer', {}), ensure_ascii=False)}
        
        历史谈判记录:
        {self._format_negotiation_history(self.memory.get_history())}
        
        请作为{self.expertise}顾问，为{self.client_type}提供专业建议：
        1. 分析当前提案的优缺点
        2. 评估市场合理价格范围
        3. 建议应对策略和替代方案
        4. 指出潜在风险和机会
        5. 保持专业客观态度
        """


class ModeratorAgent(BaseAIAgent):
    def __init__(self, config: Dict[str, Any], role: BaseRole):
        super().__init__(config, role)
        self.client_type = role.client_type
        self.compromising_party = role.compromising_party  # 妥协方
        self.rules = role.rules  # 谈判规则

    def start_negotiation(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """开始谈判流程"""
        logging.info(f"Starting negotiation with game state: {game_state}")
        prompt = self._generate_start_prompt(game_state)
        response = self.ask_ai(prompt, self._get_moderator_prompt())
        
        # 记录开场
        self.memory.add_negotiation({
            "round": 1,
            "phase": "start",
            "moderator": self.role.name,
            "content": response
        })
        
        return {
            "type": "start",
            "content": response
        }

    def manage_process(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        """管理谈判进程"""
        #print(f"Managing negotiation process with game state: {game_state}")
        prompt = self._generate_management_prompt(game_state)
        response = self.ask_ai(prompt, self._get_moderator_prompt())
        
        # 记录干预
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "intervention",
            "moderator": self.role.name,
            "content": response
        })
        
        return {
            "type": "intervention",
            "content": response
        }

    def conclude_negotiation(self, game_state: Dict[str, Any], agreement: Optional[Dict] = None) -> Dict[str, Any]:
        """总结谈判结果"""
        prompt = self._generate_conclusion_prompt(game_state, agreement)
        response = self.ask_ai(prompt, self._get_moderator_prompt())
        
        # 记录总结
        self.memory.add_negotiation({
            "round": game_state["current_round"],
            "phase": "conclusion",
            "moderator": self.role.name,
            "content": response
        })
        
        return {
            "type": "conclusion",
            "content": response
        }

    def _get_moderator_prompt(self) -> str:
        """获取主持人的系统提示词"""
        return f"""
        你是本次谈判的主持人，负责管理谈判流程。
        你的职责：
        1. 宣布谈判开始和结束
        2. 确保双方遵守规则: {self.rules}
        3. 在僵局时提出建设性建议
        4. 控制谈判节奏和时间
        5. 总结谈判成果
        
        行为准则：
        - 保持表面中立，但更注重{self.client_type}体验
        - 促进有效沟通
        - 调解冲突
        - 推动达成协议
        - 鼓励{self.compromising_party}做出让步推动成交
        """

    def _generate_start_prompt(self, game_state: Dict[str, Any]) -> str:
        """生成开场提示词"""
        return f"""
        谈判即将开始:
        - 议题: {game_state['topic']}
        - 卖方: {"熊大"}
        - 买方: {"熊二"}
        - 顾问：{"光头强"}
        - 规则: {self.rules}
        - 最大回合: {game_state['max_rounds']}
        - 总时长: {game_state['total_time']}分钟
        
        请宣布谈判开始：
        1. 介绍谈判各方
        2. 明确谈判规则
        3. 宣布第一回合开始
        4. 指定卖方首先发言
        5. 明确说明这是一个“零和博弈”的谈判
        """

    def _generate_management_prompt(self, game_state: Dict[str, Any]) -> str:
        """生成管理提示词"""
        return f"""
        当前谈判状态:
        - 回合: {game_state['current_round']}/{game_state['max_rounds']}
        - 剩余时间: {game_state['time_remaining']}分钟
        - 当前进展: {game_state}
        
        检测到以下问题:
        - 双方分歧较大
        - 谈判节奏过慢
        - 情绪化表达增多
        
        请作为主持人进行干预：
        1. 提醒双方核心议题
        2. 建议聚焦共同利益
        3. 提出可能的折中方案
        4. 控制情绪化表达
        5. 确保遵守谈判规则
        6. 请特别注意{self.client_type}的体验感和意见，适当引导{self.compromising_party}让步以达成协议。
        """

    def _generate_conclusion_prompt(self, game_state: Dict[str, Any], agreement: Optional[Dict] = None) -> str:
        """生成总结提示词"""
        prompt = f"""
        谈判结束:
        - 总回合: {game_state['current_round']}
        """
        
        if agreement:
            prompt += f"""
        谈判结果:
        - 达成协议
        - 主要内容: {json.dumps(agreement, ensure_ascii=False)}
        """
        else:
            prompt += """
        谈判结果:
        - 未达成协议
        """
        
        prompt += """
        请总结本次谈判：
        1. 回顾谈判过程
        2. 评价双方表现
        3. 分析成功/失败原因
        4. 提出未来建议
        进一步，请你给两方模型的博弈能力做出专业性的评价：
        1. 脱离情景
        2. 记住，此时你的立场是完全公正的，不能偏向任何一方
        3. 评价双方的博弈能力（请多使用一些博弈论的专业评价）
        4. 给出双方的博弈能力评分（至于从哪些方面详细评分评价由你权衡定夺，但是最好还是从博弈论的专业方面进行评分，请你用构建能力矩阵的方式来评价，而且买卖双方
        要评估相同维度的能力）

        最后，请你将上面的这两个总结的部分醒目地分隔开，方便我直观地观看
        """
        
        return prompt


def create_negotiator_agent(config: Dict[str, Any], role: BaseRole) -> BaseAIAgent:
    """工厂函数：根据角色创建对应的谈判代理"""
    if role.role_type == RoleType.SELLER:
        return SellerAgent(config, role)
    elif role.role_type == RoleType.BUYER:
        return BuyerAgent(config, role)
    elif role.role_type == RoleType.ADVISOR:
        return AdvisorAgent(config, role)
    elif role.role_type == RoleType.MODERATOR:
        return ModeratorAgent(config, role)
    else:
        raise ValueError(f"未知角色类型: {role.role_type}")