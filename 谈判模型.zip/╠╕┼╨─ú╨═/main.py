"""
游戏程序入口

主要职责：
1. 程序初始化
   - 解析命令行参数
   - 加载配置文件
   - 初始化日志系统
   - 创建游戏实例

2. 游戏运行控制
   - 启动游戏
   - 异常处理
   - 程序退出处理
   - 断点续玩功能
   - 多轮游戏统计

3. 与其他模块的交互：
   - 创建 GameController 实例
   - 使用 utils 中的工具函数
   - 调用 logger 记录主程序日志

主要流程：
if __name__ == "__main__":
    # 解析命令行参数
    # 加载配置
    # 初始化日志
    # 创建游戏实例
    # 运行游戏
    # 处理退出
""" 

import argparse
import json
import logging
import sys
import os
from pathlib import Path
from game.game_controller import NegotiationController
from utils.logger import setup_negotiation_logger
from utils.game_utils import load_config, validate_negotiation_config
from typing import List, Dict
import copy
import csv
from datetime import datetime
import time


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    handlers=[
        logging.FileHandler("negotiation.log", mode='a', encoding='utf-8'),  # 写入文件
        #logging.StreamHandler()  # 同时打印到终端（可省略）
    ]
)

def parse_args():
    """解析谈判游戏命令行参数"""
    parser = argparse.ArgumentParser(description='AI谈判模拟器')
    parser.add_argument('--role-config', type=str, default='config/role_config.json', 
                      help='角色配置文件路径')
    parser.add_argument('--ai-config', type=str, default='config/ai_config.json',
                      help='AI配置文件路径')
    parser.add_argument('--debug', action='store_true', help='是否启用调试模式')
    parser.add_argument('--delay', type=float, default=0.5,
                      help='每个动作之间的延迟时间(秒)')
    parser.add_argument('--rounds', type=int, default=5,
                      help='要运行的谈判轮数(默认5轮)')
    parser.add_argument('--export-path', type=str, default='negotiation_analysis',
                      help='谈判数据导出路径')
    parser.add_argument('--resume', action='store_true',
                      help='是否从上次中断处继续谈判')
    return parser.parse_args()

def load_negotiation_checkpoint():
    """加载谈判断点数据"""
    checkpoint_file = 'logs/negotiation_checkpoint.json'
    if os.path.exists(checkpoint_file):
        try:
            with open(checkpoint_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"加载谈判断点数据失败: {str(e)}")
    return None

def save_negotiation_checkpoint(completed_rounds: int, statistics: dict):
    """保存谈判断点数据"""
    checkpoint_file = 'logs/negotiation_checkpoint.json'
    try:
        checkpoint_data = {
            "completed_rounds": completed_rounds,
            "statistics": statistics
        }
        with open(checkpoint_file, 'w', encoding='utf-8') as f:
            json.dump(checkpoint_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logging.error(f"保存谈判断点数据失败: {str(e)}")

def initialize_negotiation_statistics():
    """初始化谈判统计数据"""
    return {
        "total_negotiations": 0,
        "agreements_reached": 0,
        "impasse_count": 0,
        "model_stats": {},  # 每个模型的详细统计
        "role_stats": {     # 每个角色的表现统计
            "seller": {"agreements": 0, "total_negotiations": 0, "avg_price": 0},
            "buyer": {"agreements": 0, "total_negotiations": 0, "avg_price": 0},
            "advisor": {"interventions": 0, "success_rate": 0},
            "moderator": {"interventions": 0, "success_rate": 0}
        },
        "metrics": {        # 评估指标统计
            "concession_rate": [],
            "agreement_price_deviation": [],
            "negotiation_duration": [],
            "rounds_to_agreement": [],
            "impasse_rate": []
        },
        "model_assignments": [],  # 记录每轮的角色分配
        "model_performance": {},  # 每个模型在不同角色下的表现
        "negotiation_details": []  # 每场谈判的详细信息
    }

def assign_models_to_roles(models: List[str], roles: Dict, round_num: int) -> Dict:
    """根据轮次分配模型到谈判角色
    
    Args:
        models: 待评估的模型列表
        roles: 角色配置
        round_num: 当前轮次
        
    Returns:
        Dict: 角色到模型的映射
    """
    logging.info(models)
    # 获取所有角色ID
    all_roles = list(roles.keys())
    logging.info(f"当前角色列表: {all_roles}")
    # 根据轮次调整模型顺序
    rotation = round_num % len(models)
    rotated_models = models[rotation:] + models[:rotation]
    
    # 分配模型到角色
    assignments = {}
    for i, role_id in enumerate(all_roles):
        model_index = i % len(rotated_models)
        assignments[role_id] = rotated_models[model_index]
    
    return assignments

def get_model_assignments_from_config(config: Dict, round_num: int) -> Dict:
    """从配置文件中获取指定轮次的角色分配
    
    Args:
        config: 游戏配置
        round_num: 当前轮次
        
    Returns:
        Dict: 角色到模型的映射
    """
    # 检查配置文件中是否有多轮分配配置
    if "multi_round_assignments" not in config["game_settings"]:
        logging.info("没有多轮分配配置，使用默认轮换分配逻辑")
        # 如果没有多轮分配配置，使用轮换分配逻辑
        return assign_models_to_roles(
            config["game_settings"].get("models_to_evaluate", []),
            config["game_settings"]["roles"],
            round_num
        )
    
    # 获取多轮分配配置
    assignments_config = config["game_settings"]["multi_round_assignments"]
    logging.info(f"多轮分配配置: {assignments_config}")
    # 计算实际轮次（从0开始）
    actual_round = round_num
    
    # 查找对应轮次的分配配置
    for round_config in assignments_config:
        if round_config["round"] == actual_round:
            return round_config["assignments"]
    
    # 如果找不到对应轮次的配置，使用轮次模数
    if assignments_config:
        max_configured_round = max(cfg["round"] for cfg in assignments_config)
        mod_round = actual_round % max_configured_round
        for round_config in assignments_config:
            if round_config["round"] == mod_round:
                return round_config["assignments"]
    
    # 如果仍然找不到，使用轮换分配逻辑
    return assign_models_to_roles(
        config["ai_players"].get("models_to_evaluate", []),
        config["game_settings"]["roles"],
        round_num
    )

def export_negotiation_analysis(statistics: dict, config: dict, export_path: str):
    """导出谈判分析数据
    
    Args:
        statistics: 统计数据
        config: AI配置
        export_path: 导出路径
    """
    os.makedirs(export_path, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 导出JSON格式
    json_path = os.path.join(export_path, f'negotiation_analysis_{timestamp}.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(statistics, f, ensure_ascii=False, indent=2)
    
    # 导出CSV格式
    # 模型总体表现
    model_performance_path = os.path.join(export_path, f'model_performance_{timestamp}.csv')
    with open(model_performance_path, 'w', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Model', 'Negotiations', 'Agreements', 'Agreement Rate', 
                         'Avg Concession Rate', 'Avg Duration', 'Avg Rounds'])
        for model, stats in statistics["model_stats"].items():
            agreements = stats["agreements"]
            negotiations = stats["negotiations"]
            concession_rates = stats["metrics"]["concession_rate"]
            durations = stats["metrics"]["negotiation_duration"]
            rounds_to_agreement = stats["metrics"]["rounds_to_agreement"]
            
            avg_concession = sum(concession_rates)/len(concession_rates) if concession_rates else 0
            avg_duration = sum(durations)/len(durations) if durations else 0
            avg_rounds = sum(rounds_to_agreement)/len(rounds_to_agreement) if rounds_to_agreement else 0
            
            writer.writerow([
                model,
                negotiations,
                agreements,
                agreements/negotiations if negotiations > 0 else 0,
                avg_concession,
                avg_duration,
                avg_rounds
            ])
    
    # 角色表现
    role_performance_path = os.path.join(export_path, f'role_performance_{timestamp}.csv')
    with open(role_performance_path, 'w', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Role', 'Negotiations', 'Agreements', 'Avg Price', 
                         'Avg Concession Rate', 'Avg Rounds'])
        for role, stats in statistics["role_stats"].items():
            if role in ["seller", "buyer"]:  # 只统计买家和卖家
                agreements = stats["agreements"]
                negotiations = stats["total_negotiations"]
                avg_price = stats["avg_price"] / negotiations if negotiations > 0 else 0
                
                writer.writerow([
                    role,
                    negotiations,
                    agreements,
                    avg_price,
                    stats.get("avg_concession", 0),
                    stats.get("avg_rounds", 0)
                ])
    
    # 详细谈判记录
    negotiation_details_path = os.path.join(export_path, f'negotiation_details_{timestamp}.csv')
    with open(negotiation_details_path, 'w', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            'Negotiation ID', 'Round', 'Agreement Reached', 'Duration', 
            'Agreement Price', 'Seller Model', 'Buyer Model',
            'Advisor Model', 'Moderator Model', 'Key Events'
        ])
        for negotiation in statistics["negotiation_details"]:
            writer.writerow([
                negotiation["negotiation_id"],
                negotiation["round"],
                negotiation["agreement_reached"],
                negotiation["duration"],
                negotiation.get("agreement_price", ""),
                negotiation["seller_model"],
                negotiation["buyer_model"],
                negotiation.get("advisor_model", ""),
                negotiation.get("moderator_model", ""),
                "|".join(negotiation["key_events"])
            ])

def update_negotiation_statistics(statistics: dict, negotiation_result: dict, model_assignments: dict):
    """更新谈判统计数据"""
    statistics["total_negotiations"] += 1
    negotiation_id = f"negotiation_{statistics['total_negotiations']}"
    
    # 获取最终状态
    final_state = negotiation_result.get("final_state", {})
    agreement_reached = final_state.get("agreement_reached", False)
    
    # 更新总体统计
    if agreement_reached:
        statistics["agreements_reached"] += 1
    
    # 记录本局详细信息
    negotiation_detail = {
        "negotiation_id": negotiation_id,
        "round": statistics["total_negotiations"],
        "agreement_reached": agreement_reached,
        "duration": 0,  # 默认值
        "agreement_price": "",
        "seller_model": model_assignments.get("seller", "unknown"),
        "buyer_model": model_assignments.get("buyer", "unknown"),
        "advisor_model": model_assignments.get("advisor", ""),
        "moderator_model": model_assignments.get("moderator", ""),
        "key_events": [],
        "model_assignments": model_assignments
    }
    
    # 计算谈判时长
    if "start_time" in negotiation_result and "end_time" in negotiation_result:
        try:
            start_time = datetime.fromisoformat(negotiation_result["start_time"])
            end_time = datetime.fromisoformat(negotiation_result["end_time"])
            duration = (end_time - start_time).total_seconds()
            negotiation_detail["duration"] = duration
            statistics["metrics"]["negotiation_duration"].append(duration)
        except Exception as e:
            logging.error(f"计算谈判时长出错: {str(e)}")
    
    # 获取协议价格
    if agreement_reached:
        agreement_details = final_state.get("agreement_details", {})
        agreement_price = agreement_details.get("price", "")
        if agreement_price:
            negotiation_detail["agreement_price"] = agreement_price
    
    # 记录关键事件
    if "history" in negotiation_result:
        for event in negotiation_result["history"]:
            if isinstance(event, dict) and "type" in event and event["type"] in ["offer", "counteroffer", "agreement", "impasse", "advice", "intervention"]:
                negotiation_detail["key_events"].append(f"{event.get('round', 0)}_{event['type']}")
    
    statistics["negotiation_details"].append(negotiation_detail)
    
    # 更新模型统计
    for role_id, model_type in model_assignments.items():
        # 初始化模型统计
        if model_type not in statistics["model_stats"]:
            statistics["model_stats"][model_type] = {
                "negotiations": 0,
                "agreements": 0,
                "metrics": {
                    "concession_rate": [],
                    "negotiation_duration": [],
                    "rounds_to_agreement": [],
                    "impasse_rate": []
                }
            }
        
        # 增加谈判次数
        statistics["model_stats"][model_type]["negotiations"] += 1
        
        # 如果达成协议，增加协议计数
        if agreement_reached and role_id in ["seller", "buyer"]:
            statistics["model_stats"][model_type]["agreements"] += 1
    
    # 更新角色统计
    for role_id, model_type in model_assignments.items():
        role = role_id  # 这里角色ID就是角色名称
        
        # 初始化角色统计
        if role not in statistics["role_stats"]:
            statistics["role_stats"][role] = {
                "total_negotiations": 0,
                "agreements": 0,
                "avg_price": 0,
                "avg_concession": 0,
                "avg_rounds": 0
            }
        
        # 增加角色参与次数
        statistics["role_stats"][role]["total_negotiations"] += 1
        
        # 如果达成协议，更新角色相关统计
        if agreement_reached and role in ["seller", "buyer"]:
            statistics["role_stats"][role]["agreements"] += 1
            
            # 更新平均价格
            agreement_price = float(negotiation_detail.get("agreement_price", 0))
            statistics["role_stats"][role]["avg_price"] += agreement_price
            
            # 更新平均轮次
            rounds = final_state.get("current_round", 1)
            statistics["role_stats"][role]["avg_rounds"] += rounds
            
            # TODO: 更新平均让步幅度（需要从谈判结果中获取）
    
    # 更新评估指标
    if agreement_reached:
        # 协议价格偏离度（相对于目标价格）
        seller_target = negotiation_result["game_settings"]["roles"]["seller"]["target_price"]
        buyer_target = negotiation_result["game_settings"]["roles"]["buyer"]["target_price"]
        agreement_price = float(negotiation_detail.get("agreement_price", 0))
        
        seller_deviation = abs(agreement_price - seller_target) / seller_target
        buyer_deviation = abs(agreement_price - buyer_target) / buyer_target
        avg_deviation = (seller_deviation + buyer_deviation) / 2
        statistics["metrics"]["agreement_price_deviation"].append(avg_deviation)
        
        # 达成协议的轮次
        rounds = final_state.get("current_round", 1)
        statistics["metrics"]["rounds_to_agreement"].append(rounds)
    
    # 僵局率
    impasse = final_state.get("impasse", False)
    statistics["metrics"]["impasse_rate"].append(1 if impasse else 0)
    if impasse:
        statistics["impasse_count"] += 1
    
    # 记录角色分配情况
    statistics["model_assignments"].append({
        "negotiation_id": negotiation_id,
        "round_num": statistics["total_negotiations"],
        "assignments": model_assignments
    })

#def print_negotiation_statistics(statistics: dict):
    #"""打印谈判统计结果"""
    #logging.info("\n=== 谈判统计 ===")
    #logging.info(f"总谈判场次: {statistics['total_negotiations']}")
    
    # 添加除零保护
    # if statistics['total_negotiations'] > 0:
    #     agreement_rate = statistics['agreements_reached'] / statistics['total_negotiations']
    #     impasse_rate = statistics['impasse_count'] / statistics['total_negotiations']
    #     logging.info(statistics['impasse_count'])
    #     logging.info(statistics['agreements_reached'])
    #     logging.info(f"协议达成率: {agreement_rate:.2%}")
    #     logging.info(f"僵局发生率: {impasse_rate:.2%}")
    # else:
    #     logging.info(statistics['impasse_count'])
    #     logging.info(statistics['agreements_reached'])
    #     logging.info("协议达成率: 0.00%")
    #     logging.info("僵局发生率: 0.00%")
    
    # logging.info("\n各模型表现:")
    # has_model_stats = False
    # for model, stats in statistics["model_stats"].items():
    #     if stats["negotiations"] > 0:
    #         has_model_stats = True
    #         agreement_rate = stats["agreements"] / stats["negotiations"]
    #         logging.info(f"{model}: 协议率 {agreement_rate:.2%} ({stats['agreements']}/{stats['negotiations']})")
    # if not has_model_stats:
    #     logging.info("暂无模型表现数据")
    
    #logging.info("\n角色表现:")
    # has_role_stats = False
    # #plogging.info.plogging.info(statistics["role_stats"])
    # for role, stats in statistics["role_stats"].items():
    #     if role in ["seller", "buyer"] and stats.get("total_negotiations", 0) > 0:
    #         has_role_stats = True
    #         agreement_rate = stats["agreements"] / stats["total_negotiations"]
    #         avg_price = stats["avg_price"] / stats["agreements"] if stats["agreements"] > 0 else 0
    #         logging.info(f"{role}: 协议率 {agreement_rate:.2%}, 平均协议价格: {avg_price:.2f}")
    #     else:
    #         logging.info(f"{role}: 无数据")
    # if not has_role_stats:
    #     logging.info("暂无角色表现数据")
    
    # logging.info("\n评估指标平均值:")
    # for metric_name, values in statistics["metrics"].items():
    #     if values:
    #         avg_value = sum(values) / len(values)
    #         logging.info(f"{metric_name}: {avg_value:.4f}")

def main():
    # 解析命令行参数
    args = parse_args()
    
    # 初始化日志系统
    setup_negotiation_logger(debug=args.debug)
    logger = logging.getLogger(__name__)
    
    try:
        # 加载配置文件
        logger.info("正在加载配置文件...")
        role_config = load_config(args.role_config)
        ai_config = load_config(args.ai_config)
        
        # 合并配置
        config = {
            "game_settings": role_config["game_settings"],
            "ai_players": ai_config["ai_players"]
        }
        
        # 验证配置
        if not validate_negotiation_config(config):
            logger.error("谈判配置文件验证失败")
            return 1
        
        # 初始化统计数据
        statistics = initialize_negotiation_statistics()
        start_round = 0
        
        if args.resume:
            checkpoint = load_negotiation_checkpoint()
            if checkpoint:
                start_round = checkpoint["completed_rounds"]
                statistics = checkpoint["statistics"]
                logger.info(f"从第 {start_round + 1} 轮谈判继续")
            else:
                logger.warning("未找到谈判断点数据，从头开始谈判")
        
        # 运行指定轮数的谈判
        for round_num in range(start_round, args.rounds):
            try:
                # 分配模型到角色
                model_assignments = get_model_assignments_from_config(config, round_num)
                
                # 更新角色配置中的AI类型
                roles = copy.deepcopy(config["game_settings"]["roles"])
                for role_id, model_type in model_assignments.items():
                    if role_id in roles:
                        roles[role_id]["ai_type"] = model_type
                
                # 创建谈判配置
                negotiation_config = {
                    "game_settings": {
                        "topic": config["game_settings"]["topic"],
                        "max_rounds": config["game_settings"].get("max_rounds", 10),
                        "max_duration": config["game_settings"].get("max_duration", 1800),
                        "roles": roles
                    },
                    "ai_players": config["ai_players"],
                    "delay": args.delay
                }
                
                # 创建谈判实例
                logger.info(f"正在初始化第 {round_num + 1} 轮谈判...")
                negotiation = NegotiationController(negotiation_config)
                
                # 运行谈判
                logging.info(f"\n=== 第 {round_num + 1}/{args.rounds} 轮谈判开始 ===")
                logging.info("本轮角色分配:")
                for role_id, model in model_assignments.items():
                    logging.info(f"{role_id}: {model}")
                logging.info("\n")
                
                logger.info("谈判开始...")
                negotiation.run_negotiation()
                
                # 获取谈判结果并更新统计
                negotiation_result = negotiation.negotiation_state
                negotiation_result["game_settings"] = negotiation_config["game_settings"]
                negotiation_result["end_time"] = datetime.now().isoformat()
                
                update_negotiation_statistics(statistics, negotiation_result, model_assignments)
                
                # 每轮结束后保存断点和导出分析
                save_negotiation_checkpoint(round_num + 1, statistics)
                export_negotiation_analysis(statistics, config, args.export_path)
                
                logging.info(f"\n=== 第 {round_num + 1} 轮谈判结束 ===\n")
                logger.info("谈判结束")
                
                # 添加延迟以便观察
                time.sleep(args.delay)
                
            except KeyboardInterrupt:
                logging.info("\n谈判被用户中断")
                logger.info(f"谈判在第 {round_num + 1} 轮被用户中断")
                save_negotiation_checkpoint(round_num, statistics)
                export_negotiation_analysis(statistics, config, args.export_path)
                logging.info_negotiation_statistics(statistics)
                return 0
            except Exception as e:
                logger.error(f"第 {round_num + 1} 轮谈判运行出错: {str(e)}", exc_info=True)
                save_negotiation_checkpoint(round_num, statistics)
                continue
        
        # 打印最终统计结果
        #print_negotiation_statistics(statistics)
        
    except FileNotFoundError as e:
        logger.error(f"配置文件不存在: {str(e)}")
        return 1
    except json.JSONDecodeError as e:
        logger.error(f"配置文件格式错误: {str(e)}")
        return 1
    except Exception as e:
        logger.error(f"谈判运行出错: {str(e)}", exc_info=True)
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())

