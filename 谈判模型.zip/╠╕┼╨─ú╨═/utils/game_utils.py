"""
游戏通用工具函数集合

主要功能：
1. 配置文件处理
   - 读取 JSON 配置
   - 验证配置有效性
   - 合并默认配置

2. 游戏辅助功能
   - 随机角色分配
   - 计算投票结果
   - 游戏状态检查
   - 定时器实现

3. 与其他模块的交互：
   - 被 game_controller.py 调用使用工具函数
   - 被 ai_players.py 使用配置处理
   - 提供通用异常处理

4. 函数列表
    - merge_configs: 深度合并配置字典
    - calculate_concession_rate: 计算让步幅度
    - detect_impasse: 检测谈判僵局
    - format_negotiation_state: 格式化谈判状态信息
    - create_negotiation_timer: 创建谈判计时器
    # - handle_negotiation_exceptions: 谈判异常处理装饰器
    - NegotiationError: 自定义异常类
""" 

import json
from typing import Dict, Any, List
import logging
import random
import time

def load_config(config_path: str) -> Dict[str, Any]:
    """加载配置文件"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"加载配置文件失败: {str(e)}")
        raise

def merge_configs(default_config: Dict[str, Any], user_config: Dict[str, Any]) -> Dict[str, Any]:
    """
    深度合并默认配置和用户配置
    
    参数:
        default_config: 默认配置字典
        user_config: 用户提供的配置字典
        
    返回:
        合并后的配置字典
    """
    merged = default_config.copy()
    
    for key, value in user_config.items():
        # 如果值是字典，则递归合并
        if isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
            merged[key] = merge_configs(merged[key], value)
        else:
            merged[key] = value
            
    return merged

def validate_negotiation_config(config: dict) -> bool:
    """验证谈判配置是否有效"""
    try:
        # 检查必要的配置项
        required_keys = ["game_settings", "ai_players"]
        if not all(key in config for key in required_keys):
            return False
            
        # 检查参与者配置
        roles = config["game_settings"]["roles"]
        required_roles = ["Seller", "Buyer", "Advisor", "Moderator"]
        if not all(role in roles for role in required_roles):
            return False  
        return True
    
    except Exception as e:
        logging.error(f"配置验证失败: {str(e)}")
        return False

def calculate_concession_rate(prev_offer: Dict, current_offer: Dict) -> float:
    """
    计算让步幅度
    
    参数:
        prev_offer: 前一次报价
        current_offer: 当前报价
        
    返回:
        让步幅度（如果是价格让步，正数表示降价，负数表示提价）
    """
    if "price" in prev_offer and "price" in current_offer:
        return prev_offer["price"] - current_offer["price"]
    return 0.0

def detect_impasse(offer_history: List[Dict], threshold: int = 3) -> bool:
    """
    检测是否陷入僵局（连续多轮没有进展）
    
    参数:
        offer_history: 报价历史记录
        threshold: 连续无进展轮数阈值
        
    返回:
        True表示陷入僵局，False表示正常
    """
    if len(offer_history) < threshold:
        return False
        
    # 获取最近的threshold+1个报价
    recent_offers = offer_history[-threshold-1:]
    
    # 检查价格变化
    prices = [offer.get("price", 0) for offer in recent_offers]
    
    # 如果连续多轮价格不变
    if all(p == prices[0] for p in prices):
        return True
        
    # 检查让步幅度是否小于阈值
    concessions = []
    for i in range(1, len(recent_offers)):
        concession = abs(calculate_concession_rate(recent_offers[i-1], recent_offers[i]))
        concessions.append(concession)
    
    # 如果连续多轮让步幅度小于1%
    if all(c < 0.01 * recent_offers[0].get("price", 100) for c in concessions):
        return True
        
    return False

def format_negotiation_state(negotiation_state: Dict[str, Any]) -> str:
    """
    格式化谈判状态信息，用于显示和日志
    
    参数:
        negotiation_state: 谈判状态字典
        
    返回:
        格式化的字符串
    """
    output = []
    output.append(f"=== 第 {negotiation_state['current_round']} 轮谈判 ===")
    output.append(f"当前阶段: {negotiation_state['phase']}")
    
    # 参与者信息
    if negotiation_state.get("roles"):
        output.append("参与者:")
        for pid, info in negotiation_state["roles"].items():
            role = info.get("role", "未知角色")
            status = "活跃" if info.get("active", True) else "非活跃"
            output.append(f"  - {pid} ({role}): {status}")
    
    # 最新报价
    if negotiation_state.get("last_offer"):
        offer = negotiation_state["last_offer"]
        proposer = offer.get("proposer", "未知")
        price = offer.get("price", "未设置")
        output.append(f"最新报价: {proposer} 报价 {price}")
    
    # 协议状态
    if negotiation_state.get("agreement_reached"):
        details = negotiation_state.get("agreement_details", {})
        price = details.get("price", "未设置")
        output.append(f"已达成协议! 价格: {price}")
    else:
        output.append("尚未达成协议")
    
    # 僵局状态
    if negotiation_state.get("impasse"):
        output.append("⚠️ 谈判陷入僵局")
    
    return "\n".join(output)

def create_negotiation_timer(duration_minutes: int) -> Dict[str, Any]:
    """
    创建谈判计时器
    
    参数:
        duration_minutes: 谈判最大持续时间（分钟）
        
    返回:
        计时器字典，包含开始时间、持续时间和检查方法
    """
    start_time = time.time()
    
    def check_timeout() -> bool:
        """检查是否超时"""
        elapsed = (time.time() - start_time) / 60  # 转换为分钟
        return elapsed >= duration_minutes
    
    return {
        "start_time": start_time,
        "duration_minutes": duration_minutes,
        "check_timeout": check_timeout
    }

def handle_negotiation_exceptions(func):
    """
    谈判异常处理装饰器
    
    参数:
        func: 要装饰的函数
        
    返回:
        包装后的函数
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyError as e:
            logging.error(f"配置缺失关键字段: {str(e)}")
            raise NegotiationConfigError(f"缺少必要的配置项: {str(e)}")
        except ValueError as e:
            logging.error(f"无效的谈判数据: {str(e)}")
            raise NegotiationDataError(f"无效数据: {str(e)}")
        except Exception as e:
            logging.exception(f"谈判过程中发生未预期错误: {str(e)}")
            raise NegotiationError(f"谈判错误: {str(e)}")
    
    return wrapper

# 自定义异常类
class NegotiationError(Exception):
    """谈判基础异常"""
    pass

class NegotiationConfigError(NegotiationError):
    """配置相关异常"""
    pass

class NegotiationDataError(NegotiationError):
    """数据相关异常"""
    pass