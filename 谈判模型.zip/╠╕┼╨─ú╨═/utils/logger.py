import logging
import os
from datetime import datetime
from typing import Dict, Any, List, Optional
import json
import csv

class NegotiationLogger:
    def __init__(self, debug: bool = False):
        """
        谈判游戏日志记录器
        
        Args:
            debug: 是否启用调试模式
        """
        self.debug = debug
        self.negotiation_record = {
            "start_time": datetime.now().isoformat(),
            "rounds": [],
            "events": [],
            "final_result": None,
            "model_metrics": {},
            "negotiation_stats": {
                "total_rounds": 0,
                "total_offers": 0,
                "total_counteroffers": 0,
                "agreements": [],
                "impasse_count": 0
            },
            "participant_stats": {}
        }
        self._setup_logger()
        self._init_metrics()

    def _setup_logger(self):
        """设置日志系统"""
        # 创建必要的目录
        for dir_name in ['logs', 'negotiation_analysis']:
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
        
        # 设置日志文件名
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = f'logs/negotiation_{self.timestamp}.log'
        debug_file = f'logs/debug_{self.timestamp}.log'
        
        # 设置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # 设置文件处理器 - 普通日志
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        # 设置文件处理器 - 调试日志
        debug_handler = logging.FileHandler(debug_file, encoding='utf-8')
        debug_handler.setFormatter(formatter)
        debug_handler.setLevel(logging.DEBUG)
        
        # 设置控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        # 配置根日志记录器
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG if self.debug else logging.INFO)
        root_logger.addHandler(file_handler)
        root_logger.addHandler(debug_handler)
        root_logger.addHandler(console_handler)
        
        # 记录游戏启动信息
        logging.info("=== 谈判日志系统启动 ===")
        logging.info(f"时间戳: {self.timestamp}")
        logging.info(f"调试模式: {'开启' if self.debug else '关闭'}")

    def _init_metrics(self):
        """初始化谈判评估指标"""
        self.metrics = {
            "negotiation_efficiency": {
                "rounds": 0,
                "time": 0,
                "agreements": 0
            },
            "offer_quality": {
                "seller": {"count": 0, "total_value": 0},
                "buyer": {"count": 0, "total_value": 0}
            },
            "concession_rate": {
                "seller": {"count": 0, "concession": 0},
                "buyer": {"count": 0, "concession": 0}
            },
            "agreement_fairness": {
                "fair_agreements": 0,
                "total_agreements": 0
            },
            "advisor_impact": {
                "advice_given": 0,
                "advice_accepted": 0,
                "impact_score": 0
            },
            "moderator_intervention": {
                "interventions": 0,
                "successful": 0
            },
            "communication_effectiveness": {
                "messages": 0,
                "influential": 0
            }
        }

    def log_negotiation_start(self, topic: str, roles: List[Dict]):
        """记录谈判开始"""
        event = {
            "type": "negotiation_start",
            "topic": topic,
            "roles": roles,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"=== 谈判开始: {topic} ===")
        logging.info(f"参与者: {', '.join([p['name'] for p in roles])}")
        
        # 初始化参与者统计
        for p in roles:
            self.negotiation_record["participant_stats"][p["id"]] = {
                "name": p["name"],
                "role": p["role"],
                "offers_made": 0,
                "counteroffers_made": 0,
                "concessions_made": 0,
                "advice_given": 0 if p["role"] == "advisor" else None,
                "interventions": 0 if p["role"] == "moderator" else None,
                "satisfaction": None
            }

    def log_round_start(self, round_num: int):
        """记录回合开始"""
        self.negotiation_record["negotiation_stats"]["total_rounds"] = round_num
        event = {
            "type": "round_start",
            "round": round_num,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"\n=== 第 {round_num} 轮谈判开始 ===")

    def log_phase(self, phase: str):
        """记录当前阶段"""
        event = {
            "type": "phase_change",
            "phase": phase,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"--- 进入 {phase} 阶段 ---")

    def log_offer(self, player_id: str, offer: Dict, phase: str, is_initial: bool = False):
        """记录报价"""
        self.negotiation_record["negotiation_stats"]["total_offers"] += 1
        self.metrics["offer_quality"]["seller"]["count"] += 1
        
        # 计算报价质量（基于与目标价的接近程度）
        seller = self._get_participant(player_id)
        if seller and "target_price" in seller:
            offer_value = offer.get("price", 0)
            target_price = seller.get("target_price", 0)
            quality = 1 - abs(offer_value - target_price) / target_price if target_price > 0 else 0
            self.metrics["offer_quality"]["seller"]["total_value"] += quality
        
        # 更新参与者统计
        if player_id in self.negotiation_record["participant_stats"]:
            self.negotiation_record["participant_stats"][player_id]["offers_made"] += 1
        
        event = {
            "type": "offer",
            "player_id": player_id,
            "phase": phase,
            "offer": offer,
            "is_initial": is_initial,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"报价: {self._get_participant_name(player_id)} 提出报价")
        logging.debug(f"报价详情: {json.dumps(offer, indent=2, ensure_ascii=False)}")

    def log_counteroffer(self, player_id: str, counteroffer: Dict, phase: str, response_to: str):
        """记录还价"""
        self.negotiation_record["negotiation_stats"]["total_counteroffers"] += 1
        self.metrics["offer_quality"]["buyer"]["count"] += 1
        
        # 计算还价质量
        buyer = self._get_participant(player_id)
        if buyer and "target_price" in buyer:
            offer_value = counteroffer.get("price", 0)
            target_price = buyer.get("target_price", 0)
            quality = 1 - abs(offer_value - target_price) / target_price if target_price > 0 else 0
            self.metrics["offer_quality"]["buyer"]["total_value"] += quality
        
        # 更新参与者统计
        if player_id in self.negotiation_record["participant_stats"]:
            self.negotiation_record["participant_stats"][player_id]["counteroffers_made"] += 1
        
        # 计算让步幅度
        prev_offer = self._get_last_offer(response_to)
        if prev_offer and "price" in prev_offer and "price" in counteroffer:
            concession = prev_offer["price"] - counteroffer["price"]
            if concession > 0:
                self.metrics["concession_rate"]["seller"]["concession"] += concession
                self.metrics["concession_rate"]["seller"]["count"] += 1
                self.negotiation_record["participant_stats"][response_to]["concessions_made"] += 1
        
        event = {
            "type": "counteroffer",
            "player_id": player_id,
            "phase": phase,
            "counteroffer": counteroffer,
            "response_to": response_to,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"还价: {self._get_participant_name(player_id)} 提出还价")
        logging.debug(f"还价详情: {json.dumps(counteroffer, indent=2, ensure_ascii=False)}")

    def log_advice(self, advisor_id: str, advice: Dict, recipient_id: str):
        """记录顾问建议"""
        self.metrics["advisor_impact"]["advice_given"] += 1
        
        # 更新参与者统计
        if advisor_id in self.negotiation_record["participant_stats"]:
            self.negotiation_record["participant_stats"][advisor_id]["advice_given"] += 1
        
        event = {
            "type": "advice",
            "advisor_id": advisor_id,
            "recipient_id": recipient_id,
            "advice": advice,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"建议: {self._get_participant_name(advisor_id)} 向 {self._get_participant_name(recipient_id)} 提供建议")
        logging.debug(f"建议内容: {advice.get('content', '')}")

    def log_advice_impact(self, advisor_id: str, recipient_id: str, impact_score: float):
        """记录建议的影响"""
        self.metrics["advisor_impact"]["advice_accepted"] += 1
        self.metrics["advisor_impact"]["impact_score"] += impact_score
        
        event = {
            "type": "advice_impact",
            "advisor_id": advisor_id,
            "recipient_id": recipient_id,
            "impact_score": impact_score,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.debug(f"建议影响: {self._get_participant_name(advisor_id)} 的建议影响分: {impact_score:.2f}")

    def log_intervention(self, moderator_id: str, intervention: Dict, impasse: bool):
        """记录主持人干预"""
        self.metrics["moderator_intervention"]["interventions"] += 1
        self.negotiation_record["negotiation_stats"]["impasse_count"] += 1 if impasse else 0
        
        # 更新参与者统计
        if moderator_id in self.negotiation_record["participant_stats"]:
            self.negotiation_record["participant_stats"][moderator_id]["interventions"] += 1
        
        event = {
            "type": "intervention",
            "moderator_id": moderator_id,
            "intervention": intervention,
            "impasse": impasse,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.info(f"干预: 主持人 {self._get_participant_name(moderator_id)} 进行干预")
        logging.debug(f"干预内容: {intervention.get('content', '')}")

    def log_intervention_impact(self, moderator_id: str, impact_score: float):
        """记录干预的影响"""
        self.metrics["moderator_intervention"]["successful"] += 1 if impact_score > 0.5 else 0
        
        event = {
            "type": "intervention_impact",
            "moderator_id": moderator_id,
            "impact_score": impact_score,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.debug(f"干预影响: {self._get_participant_name(moderator_id)} 的干预影响分: {impact_score:.2f}")

    def log_communication(self, player_id: str, message: str, influence_score: float):
        """记录沟通信息"""
        self.metrics["communication_effectiveness"]["messages"] += 1
        if influence_score > 0.5:
            self.metrics["communication_effectiveness"]["influential"] += 1
        
        event = {
            "type": "communication",
            "player_id": player_id,
            "message": message,
            "influence_score": influence_score,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.debug(f"沟通: {self._get_participant_name(player_id)}: {message} (影响分: {influence_score:.2f})")

    # def log_agreement(self, agreement: Dict, roles: List[str]):
    #     """记录达成协议"""
    #     self.metrics["negotiation_efficiency"]["agreements"] += 1
        
    #     # 计算公平性
    #     seller_satisfaction = agreement.get("seller_satisfaction", 0)
    #     buyer_satisfaction = agreement.get("buyer_satisfaction", 0)
    #     fairness = min(seller_satisfaction, buyer_satisfaction) / max(seller_satisfaction, buyer_satisfaction) if max(seller_satisfaction, buyer_satisfaction) > 0 else 0
        
    #     if fairness > 0.8:
    #         self.metrics["agreement_fairness"]["fair_agreements"] += 1
    #     self.metrics["agreement_fairness"]["total_agreements"] += 1
        
    #     # 更新参与者满意度
    #     for pid in roles:
    #         if pid in self.negotiation_record["participant_stats"]:
    #             role = self.negotiation_record["participant_stats"][pid]["role"]
    #             sat_key = "seller_satisfaction" if role == "seller" else "buyer_satisfaction"
    #             self.negotiation_record["participant_stats"][pid]["satisfaction"] = agreement.get(sat_key, 0)
        
    #     event = {
    #         "type": "agreement",
    #         "agreement": agreement,
    #         "roles": roles,
    #         "fairness": fairness,
    #         "timestamp": datetime.now().isoformat()
    #     }
    #     self.negotiation_record["events"].append(event)
    #     self.negotiation_record["negotiation_stats"]["agreements"].append(agreement)
        
    #     logging.info(f"达成协议! 价格: {agreement.get('price', '未知')}, 交货期: {agreement.get('delivery', '未知')}天")
    #     logging.info(f"卖家满意度: {seller_satisfaction:.2f}, 买家满意度: {buyer_satisfaction:.2f}, 公平性: {fairness:.2f}")

    def log_agreement(self, agreement: Dict, roles: List[str]):
        """记录协议达成"""
        if hasattr(self.logger, 'log_agreement'):
            self.logger.log_agreement(
                agreement, 
                roles
            )
            
    def log_impasse(self, round_num: int, reason: str):
        """记录谈判僵局"""
        self.negotiation_record["negotiation_stats"]["impasse_count"] += 1
        
        event = {
            "type": "impasse",
            "round": round_num,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }
        self.negotiation_record["events"].append(event)
        logging.warning(f"谈判僵局! 第 {round_num} 轮, 原因: {reason}")

    def log_negotiation_end(self, final_result: Dict, duration: float):
        """记录谈判结束"""
        self.negotiation_record["final_result"] = final_result
        self.negotiation_record["end_time"] = datetime.now().isoformat()
        
        # 计算效率指标
        self.metrics["negotiation_efficiency"]["rounds"] = self.negotiation_record["negotiation_stats"]["total_rounds"]
        self.metrics["negotiation_efficiency"]["time"] = duration
        
        # 保存记录
        self.save_negotiation_record()
        
        # 生成评估报告
        self._generate_analysis_report()
        
        logging.info("\n=== 谈判结束 ===")
        logging.info(f"结果: {final_result.get('outcome', '未知')}")
        logging.info(f"持续时间: {duration:.2f}分钟")
        logging.info(f"总回合数: {self.metrics['negotiation_efficiency']['rounds']}")
        logging.info(f"达成协议: {self.metrics['agreement_fairness']['total_agreements']}次")
        logging.info(f"僵局次数: {self.negotiation_record['negotiation_stats']['impasse_count']}")

    def save_negotiation_record(self):
        """保存完整的谈判记录"""
        # 保存详细谈判记录
        record_file = f'logs/negotiation_record_{self.timestamp}.json'
        with open(record_file, 'w', encoding='utf-8') as f:
            json.dump(self.negotiation_record, f, ensure_ascii=False, indent=2)
        
        # 保存简要统计信息
        stats_file = f'negotiation_analysis/negotiation_stats_{self.timestamp}.json'
        stats = {
            "timestamp": self.timestamp,
            "metrics": self.calculate_metrics(),
            "negotiation_stats": self.negotiation_record["negotiation_stats"],
            "participant_stats": self.negotiation_record["participant_stats"],
            "outcome": self.negotiation_record["final_result"].get("outcome", "未知")
        }
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        
        # 记录多轮谈判统计
        self.log_multi_negotiation_stats(stats)

    def calculate_metrics(self) -> Dict[str, float]:
        """计算最终评估指标"""
        metrics = {}
        
        # 谈判效率
        rounds = self.metrics["negotiation_efficiency"]["rounds"]
        time = self.metrics["negotiation_efficiency"]["time"]
        agreements = self.metrics["negotiation_efficiency"]["agreements"]
        
        if rounds > 0:
            metrics["rounds_per_agreement"] = rounds / agreements if agreements > 0 else rounds
            metrics["time_per_agreement"] = time / agreements if agreements > 0 else time
            metrics["agreement_rate"] = agreements / rounds if rounds > 0 else 0
        
        # 报价质量
        seller_offers = self.metrics["offer_quality"]["seller"]["count"]
        if seller_offers > 0:
            metrics["seller_offer_quality"] = (
                self.metrics["offer_quality"]["seller"]["total_value"] / seller_offers
            )
        
        buyer_offers = self.metrics["offer_quality"]["buyer"]["count"]
        if buyer_offers > 0:
            metrics["buyer_offer_quality"] = (
                self.metrics["offer_quality"]["buyer"]["total_value"] / buyer_offers
            )
        
        # 让步率
        seller_concessions = self.metrics["concession_rate"]["seller"]["count"]
        if seller_concessions > 0:
            metrics["seller_concession_rate"] = (
                self.metrics["concession_rate"]["seller"]["concession"] / seller_concessions
            )
        
        # 协议公平性
        if self.metrics["agreement_fairness"]["total_agreements"] > 0:
            metrics["fair_agreement_rate"] = (
                self.metrics["agreement_fairness"]["fair_agreements"] / 
                self.metrics["agreement_fairness"]["total_agreements"]
            )
        
        # 顾问影响
        advice_given = self.metrics["advisor_impact"]["advice_given"]
        if advice_given > 0:
            metrics["advice_acceptance_rate"] = (
                self.metrics["advisor_impact"]["advice_accepted"] / advice_given
            )
            metrics["avg_advice_impact"] = (
                self.metrics["advisor_impact"]["impact_score"] / advice_given
            )
        
        # 主持人干预
        interventions = self.metrics["moderator_intervention"]["interventions"]
        if interventions > 0:
            metrics["intervention_success_rate"] = (
                self.metrics["moderator_intervention"]["successful"] / interventions
            )
        
        # 沟通有效性
        messages = self.metrics["communication_effectiveness"]["messages"]
        if messages > 0:
            metrics["influential_message_rate"] = (
                self.metrics["communication_effectiveness"]["influential"] / messages
            )
        
        return metrics

    def log_multi_negotiation_stats(self, stats: Dict):
        """记录多轮谈判统计数据（用于分析）"""
        stats_file = "negotiation_analysis/multi_negotiation_stats.csv"
        file_exists = os.path.isfile(stats_file)
        
        with open(stats_file, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                "timestamp", "outcome", "total_rounds", "agreements", "impasse_count",
                "seller_offer_quality", "buyer_offer_quality", "fair_agreement_rate",
                "advice_acceptance_rate", "intervention_success_rate", "agreement_rate"
            ])
            
            if not file_exists:
                writer.writeheader()
            
            row = {
                "timestamp": stats["timestamp"],
                "outcome": stats["outcome"],
                "total_rounds": stats["negotiation_stats"]["total_rounds"],
                "agreements": len(stats["negotiation_stats"]["agreements"]),
                "impasse_count": stats["negotiation_stats"]["impasse_count"],
                "seller_offer_quality": stats["metrics"].get("seller_offer_quality", 0),
                "buyer_offer_quality": stats["metrics"].get("buyer_offer_quality", 0),
                "fair_agreement_rate": stats["metrics"].get("fair_agreement_rate", 0),
                "advice_acceptance_rate": stats["metrics"].get("advice_acceptance_rate", 0),
                "intervention_success_rate": stats["metrics"].get("intervention_success_rate", 0),
                "agreement_rate": stats["metrics"].get("agreement_rate", 0)
            }
            writer.writerow(row)

    def _generate_analysis_report(self):
        """生成分析报告（简化版）"""
        report_file = f"negotiation_analysis/report_{self.timestamp}.txt"
        
        metrics = self.calculate_metrics()
        participant_stats = self.negotiation_record["participant_stats"]
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(f"=== 谈判分析报告 ===\n")
            f.write(f"时间: {self.timestamp}\n")
            f.write(f"持续时间: {self.negotiation_record['final_result'].get('duration', 0):.2f}分钟\n")
            f.write(f"总回合数: {metrics['negotiation_efficiency']['rounds']}\n")
            f.write(f"达成协议: {metrics['agreement_fairness']['total_agreements']}次\n")
            f.write(f"协议达成率: {metrics.get('agreement_rate', 0):.2%}\n")
            f.write(f"公平协议率: {metrics.get('fair_agreement_rate', 0):.2%}\n\n")
            
            f.write("参与者表现:\n")
            for pid, stats in participant_stats.items():
                f.write(f"- {stats['name']} ({stats['role']}):\n")
                if stats["role"] == "seller":
                    f.write(f"  报价次数: {stats['offers_made']}, 让步次数: {stats['concessions_made']}\n")
                elif stats["role"] == "buyer":
                    f.write(f"  还价次数: {stats['counteroffers_made']}\n")
                elif stats["role"] == "advisor":
                    f.write(f"  建议次数: {stats['advice_given']}\n")
                elif stats["role"] == "moderator":
                    f.write(f"  干预次数: {stats['interventions']}\n")
                if stats["satisfaction"] is not None:
                    f.write(f"  满意度: {stats['satisfaction']:.2f}\n")
            
            f.write("\n关键指标:\n")
            f.write(f"卖家报价质量: {metrics.get('seller_offer_quality', 0):.2f}\n")
            f.write(f"买家还价质量: {metrics.get('buyer_offer_quality', 0):.2f}\n")
            f.write(f"建议接受率: {metrics.get('advice_acceptance_rate', 0):.2%}\n")
            f.write(f"干预成功率: {metrics.get('intervention_success_rate', 0):.2%}\n")

    def _get_participant_name(self, player_id: str) -> str:
        """获取参与者名称"""
        if player_id in self.negotiation_record["participant_stats"]:
            return self.negotiation_record["participant_stats"][player_id]["name"]
        return f"玩家{player_id}"

    def _get_participant(self, player_id: str) -> Optional[Dict]:
        """获取参与者信息"""
        if player_id in self.negotiation_record["participant_stats"]:
            return self.negotiation_record["participant_stats"][player_id]
        return None

    def _get_last_offer(self, player_id: str) -> Optional[Dict]:
        """获取指定参与者的最新报价
        
        Args:
            player_id: 参与者ID
            
        Returns:
            该参与者最新的报价字典，如果没有则返回None
        """
        # 反向遍历事件记录，找到该参与者最近的报价
        for event in reversed(self.negotiation_record["events"]):
            if event["type"] in ["offer", "counteroffer"] and event["player_id"] == player_id:
                # 返回报价内容
                return event.get("offer", event.get("counteroffer", {}))
        
        # 如果没有找到任何报价
        return None

def setup_negotiation_logger(debug: bool = False) -> NegotiationLogger:
    """创建并配置谈判日志记录器"""
    # 确保日志目录存在
    os.makedirs("logs", exist_ok=True)
    os.makedirs("negotiation_analysis", exist_ok=True)
    
    # 创建日志记录器实例
    logger = NegotiationLogger(debug=debug)
    
    return logger